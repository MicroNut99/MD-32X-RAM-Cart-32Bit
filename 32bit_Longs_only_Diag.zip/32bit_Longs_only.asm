    org $00000000

; ====================================================================
; 1. VECTOR TABLE
; ====================================================================
    dc.l $00FF0000          ; Initial Stack Pointer (Top of RAM)
    dc.l EntryPoint         ; FIX: Pointed directly to the EntryPoint label
    rept 62
    dc.l ExceptionHandler
    endr

; ====================================================================
; 2. ROM HEADER
; ====================================================================
    org $00000100
    dc.b "SEGA MEGA DRIVE ", "   MICRONUT     ", "STRICT LONG TEST ", "STRICT LONG TEST ", "GM 00000000-00", $00, $00, "J               "
    dc.l $00000000, $003FFFFF, $00FF0000, $00FFFFFF
    dc.b "RA",$A0,$20, $00, $20, $00, $00, $3F, $FF, "                ", "U               "

; ====================================================================
; 3. HARDENED SYSTEM INITIALIZATION
; ====================================================================
    org $00000200
EntryPoint:
    ; --- TMSS UNLOCK ---
    move.b  $A10001,d0
    andi.b  #$0F,d0
    beq.s   .skip_tmss
    move.l  #'SEGA',$A14000
.skip_tmss:

    ; --- Z80 HARDWARE LOCKOUT ---
    move.w  #$0100,$A11100      
    move.w  #$0100,$A11200      
.wait_z80:
    btst    #8,$A11100          
    bne.s   .wait_z80           

    ; --- SILENCE PSG AUDIO ---
    move.b  #$9F,$C00011
    move.b  #$BF,$C00011
    move.b  #$DF,$C00011
    move.b  #$FF,$C00011

    ; --- PURGE SYSTEM WORK RAM ---
    lea     $FF0000,a0
    move.w  #$3FFF,d0           
    moveq   #0,d1               
.clear_ram:
    move.l  d1,(a0)+
    dbra    d0,.clear_ram

    ; --- INITIALIZE VDP REGISTERS ---
    lea     VDPRegisters(pc),a0
    move.l  #$00008000,d0
    moveq   #15,d2              
.init_vdp_loop:
    move.b  (a0)+,d0
    move.w  d0,$C00004
    addi.w  #$0100,d0
    dbra    d2,.init_vdp_loop

    ; --- PURGE CRAM (COLOR RAM) ---
    move.l  #$C0000000,$C00004  
    moveq   #31,d2              
.clear_cram:
    move.l  d1,$C00000          
    dbra    d2,.clear_cram

    ; --- RELEASE Z80 ---
    move.w  #$0000,$A11200      
    move.w  #$0000,$A11100      

; ====================================================================
; 4. GENERATE HIGH-ENTROPY DATA & TEST HARDWARE
; ====================================================================
    ; Generate a rotating pattern in System RAM
    lea     $FF0000,a0
    move.w  #1023,d0            ; 1024 bytes
    move.b  #$07,d1             ; Start pattern at $07
.prep_loop:
    move.b  d1,(a0)+
    addi.b  #13,d1              ; addi allows up to 255. Adds entropy!
    dbra    d0,.prep_loop

    ; Now we test YOUR hardware at $200000
    move.l  #$00000400,-(sp)    ; Push Length (1024 bytes)
    move.l  #$00FF0000,-(sp)    ; Push Source (Our generated pattern)
    move.l  #$00200000,-(sp)    ; Push Destination (YOUR CUSTOM CARTRIDGE SRAM!)

    bsr.w   md_memcpy           ; Execute the copy

.Hang:
    bra.s   .Hang               ; Stay here forever when finished

; ====================================================================
; EXCEPTION HANDLERS & VDP DATA
; ====================================================================
ExceptionHandler:
    move.l  #$C0000000,$C00004  
    move.w  #$0EEE,$C00000      ; White background on crash
.ex_loop:
    bra.s   .ex_loop

VDPRegisters:
    dc.b $04, $44, $30, $40, $07, $6A, $00, $00
    dc.b $00, $00, $08, $00, $81, $34, $00, $02
    even

; ====================================================================
; 5. THE PRIMARY ROUTINE: md_memcpy (STRICT 32-BIT ONLY)
; ====================================================================
md_memcpy:
    ; --- PHASE 1: LOADING (BLUE) ---
    move.l  #$C0000000,$C00004  
    move.w  #$0E00,$C00000      ; Pure Blue
    move.l  #$00100000,d1       
.DelayBlue:
    subq.l  #1,d1
    bne.s   .DelayBlue

    ; Load arguments from stack
    movea.l 4(sp),a1            ; dst
    movea.l 8(sp),a0            ; src
    move.l  12(sp),d0           ; len (in bytes)
    beq.s   .StartVerify        ; If len = 0, skip to verify

    ; Convert byte count to 32-bit longword count (Divide by 4)
    lsr.l   #2,d0
    beq.s   .StartVerify        ; If length is less than 4 bytes, skip

    ; --- STRICT 32-BIT LONGWORD LOOP (NO FALLBACKS) ---
.LongLoop:
    move.l  (a0)+,(a1)+         ; FORCE 32-bit hardware write
    subq.l  #1,d0               ; Decrement longword counter
    bne.s   .LongLoop

    ; -----------------------------------------------------------
    ; PHASE 2: CHECKING HARDWARE DATA INTEGRITY (CYAN)
    ; -----------------------------------------------------------
.StartVerify:
    move.l  #$C0000000,$C00004
    move.w  #$0EE0,$C00000      ; Cyan 
    move.l  #$00100000,d1
.DelayCyan:
    subq.l  #1,d1
    bne.s   .DelayCyan

    ; Reload arguments to reset our pointers for the verification
    movea.l 4(sp),a1            ; dst
    movea.l 8(sp),a0            ; src
    move.l  12(sp),d0           ; len (in bytes)
    beq.s   .DoneGreen          

    ; We verify byte-by-byte to catch EXACTLY which bus lane dropped the data
.VerifyLoop:
    move.b  (a0)+,d1            ; Read expected source byte
    cmp.b   (a1)+,d1            ; Compare it directly to what the hardware actually saved
    bne.s   .DoneRed            ; MISMATCH! Hardware dropped the bits. Jump to Red!
    subq.l  #1,d0
    bne.s   .VerifyLoop         

    ; -----------------------------------------------------------
    ; PHASE 3A: SUCCESS (GREEN) - Hardware fully accepted the 32-bit data
    ; -----------------------------------------------------------
.DoneGreen:
    move.l  #$C0000000,$C00004
    move.w  #$00E0,$C00000      ; Green
    bra.s   .DelayFinish

    ; -----------------------------------------------------------
    ; PHASE 3B: HARDWARE FAILED (RED) - Data corrupted / Bits lost
    ; -----------------------------------------------------------
.DoneRed:
    move.l  #$C0000000,$C00004
    move.w  #$000E,$C00000      ; Red

.DelayFinish:
    move.l  #$00100000,d1       
.DelayEndLoop:
    subq.l  #1,d1
    bne.s   .DelayEndLoop

    moveq.l #0,d0               
    rts
