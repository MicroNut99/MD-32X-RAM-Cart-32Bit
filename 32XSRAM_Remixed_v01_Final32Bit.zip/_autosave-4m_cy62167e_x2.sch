(kicad_sch
	(version 20250114)
	(generator "eeschema")
	(generator_version "9.0")
	(uuid "18b14b53-a9a3-4f8f-9d9c-81b8c20b5be1")
	(paper "A4" portrait)
	(title_block
		(title "Mega RAM-Cart 4MB SRAM for Sega Megadrive & 32X")
		(rev "1")
		(comment 1 "This documentation describes Open Hardware and is licensed under the CERN OHL v.1.2")
		(comment 2 "Copyright: MiGeRA (aka Th.K)")
	)
	(lib_symbols
		(symbol "Device:Battery_Cell"
			(pin_numbers
				(hide yes)
			)
			(pin_names
				(offset 0)
				(hide yes)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "BT"
				(at 2.54 2.54 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left)
				)
			)
			(property "Value" "Battery_Cell"
				(at 2.54 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left)
				)
			)
			(property "Footprint" ""
				(at 0 1.524 90)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Datasheet" "~"
				(at 0 1.524 90)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Description" "Single-cell battery"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_keywords" "battery cell"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "Battery_Cell_0_1"
				(rectangle
					(start -2.286 1.778)
					(end 2.286 1.524)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type outline)
					)
				)
				(rectangle
					(start -1.524 1.016)
					(end 1.524 0.508)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type outline)
					)
				)
				(polyline
					(pts
						(xy 0 1.778) (xy 0 2.54)
					)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 0.762) (xy 0 0)
					)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.762 3.048) (xy 1.778 3.048)
					)
					(stroke
						(width 0.254)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.27 3.556) (xy 1.27 2.54)
					)
					(stroke
						(width 0.254)
						(type default)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "Battery_Cell_1_1"
				(pin passive line
					(at 0 5.08 270)
					(length 2.54)
					(name "+"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 0 -2.54 90)
					(length 2.54)
					(name "-"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
			(embedded_fonts no)
		)
		(symbol "Device:C_Small"
			(pin_numbers
				(hide yes)
			)
			(pin_names
				(offset 0.254)
				(hide yes)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "C"
				(at 0.254 1.778 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left)
				)
			)
			(property "Value" "C_Small"
				(at 0.254 -2.032 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Datasheet" "~"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Description" "Unpolarized capacitor, small symbol"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_keywords" "capacitor cap"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "C_*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "C_Small_0_1"
				(polyline
					(pts
						(xy -1.524 0.508) (xy 1.524 0.508)
					)
					(stroke
						(width 0.3048)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.524 -0.508) (xy 1.524 -0.508)
					)
					(stroke
						(width 0.3302)
						(type default)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "C_Small_1_1"
				(pin passive line
					(at 0 2.54 270)
					(length 2.032)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 0 -2.54 90)
					(length 2.032)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
			(embedded_fonts no)
		)
		(symbol "Device:R_Small"
			(pin_numbers
				(hide yes)
			)
			(pin_names
				(offset 0.254)
				(hide yes)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "R"
				(at 0 0 90)
				(effects
					(font
						(size 1.016 1.016)
					)
				)
			)
			(property "Value" "R_Small"
				(at 1.778 0 90)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Datasheet" "~"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Description" "Resistor, small symbol"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_keywords" "R resistor"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "R_*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "R_Small_0_1"
				(rectangle
					(start -0.762 1.778)
					(end 0.762 -1.778)
					(stroke
						(width 0.2032)
						(type default)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "R_Small_1_1"
				(pin passive line
					(at 0 2.54 270)
					(length 0.762)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 0 -2.54 90)
					(length 0.762)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
			(embedded_fonts no)
		)
		(symbol "Device:R_US"
			(pin_numbers
				(hide yes)
			)
			(pin_names
				(offset 0)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "R"
				(at 2.54 0 90)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Value" "R_US"
				(at -2.54 0 90)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 1.016 -0.254 90)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Datasheet" "~"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Description" "Resistor, US symbol"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_keywords" "R res resistor"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "R_*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "R_US_0_1"
				(polyline
					(pts
						(xy 0 2.286) (xy 0 2.54)
					)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 2.286) (xy 1.016 1.905) (xy 0 1.524) (xy -1.016 1.143) (xy 0 0.762)
					)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 0.762) (xy 1.016 0.381) (xy 0 0) (xy -1.016 -0.381) (xy 0 -0.762)
					)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 -0.762) (xy 1.016 -1.143) (xy 0 -1.524) (xy -1.016 -1.905) (xy 0 -2.286)
					)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 -2.286) (xy 0 -2.54)
					)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "R_US_1_1"
				(pin passive line
					(at 0 3.81 270)
					(length 1.27)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 0 -3.81 90)
					(length 1.27)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
			(embedded_fonts no)
		)
		(symbol "MegaDriveCart:BA6162"
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "U"
				(at 3.81 1.27 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left)
				)
			)
			(property "Value" "BA6162"
				(at 3.81 -1.27 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left)
				)
			)
			(property "Footprint" "Package_SO:SSOP-8_3.9x5.05mm_P1.27mm"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
						(italic yes)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Description" "Reset IC with battery backup function, SOP-8"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_keywords" "BMS"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "Package_SO:SOP-8_3.9x4.9mm_P1.27mm"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "BA6162_0_1"
				(rectangle
					(start -7.62 5.08)
					(end 2.54 -5.08)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type background)
					)
				)
			)
			(symbol "BA6162_1_1"
				(pin open_collector line
					(at -10.16 2.54 0)
					(length 2.54)
					(name "RESET"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin open_collector line
					(at -10.16 0 0)
					(length 2.54)
					(name "CS"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin open_collector line
					(at -10.16 -2.54 0)
					(length 2.54)
					(name "CSB"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "5"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin no_connect line
					(at -5.08 -7.62 90)
					(length 2.54)
					(hide yes)
					(name "NC"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "7"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at -2.54 -7.62 90)
					(length 2.54)
					(name "Vbat"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "4"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at 0 7.62 270)
					(length 2.54)
					(name "VCC"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "8"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at 0 -7.62 90)
					(length 2.54)
					(name "GND"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_out line
					(at 5.08 0 180)
					(length 2.54)
					(name "Vo"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "6"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
			(embedded_fonts no)
		)
		(symbol "MegaDriveCart:cy62167e-TSOP48"
			(pin_names
				(offset 1.016)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "U"
				(at 0 29.21 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Value" "cy62167e-TSOP48"
				(at 0 -34.29 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 46.99 64.77 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 46.99 64.77 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "cy62167e-TSOP48_1_1"
				(rectangle
					(start -12.7 27.94)
					(end 12.7 -33.02)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type background)
					)
				)
				(pin input line
					(at -17.78 25.4 0)
					(length 5.08)
					(name "A0"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "25"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -17.78 22.86 0)
					(length 5.08)
					(name "A1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "24"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -17.78 20.32 0)
					(length 5.08)
					(name "A2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "23"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -17.78 17.78 0)
					(length 5.08)
					(name "A3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "22"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -17.78 15.24 0)
					(length 5.08)
					(name "A4"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "21"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -17.78 12.7 0)
					(length 5.08)
					(name "A5"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "20"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -17.78 10.16 0)
					(length 5.08)
					(name "A6"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "19"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -17.78 7.62 0)
					(length 5.08)
					(name "A7"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "18"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -17.78 5.08 0)
					(length 5.08)
					(name "A8"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "8"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -17.78 2.54 0)
					(length 5.08)
					(name "A9"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "7"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -17.78 0 0)
					(length 5.08)
					(name "A10"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "6"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -17.78 -2.54 0)
					(length 5.08)
					(name "A11"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "5"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -17.78 -5.08 0)
					(length 5.08)
					(name "A12"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "4"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -17.78 -7.62 0)
					(length 5.08)
					(name "A13"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -17.78 -10.16 0)
					(length 5.08)
					(name "A14"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -17.78 -12.7 0)
					(length 5.08)
					(name "A15"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -17.78 -15.24 0)
					(length 5.08)
					(name "A16"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "48"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -17.78 -17.78 0)
					(length 5.08)
					(name "A17"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "17"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -17.78 -20.32 0)
					(length 5.08)
					(name "A18"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "16"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -17.78 -22.86 0)
					(length 5.08)
					(name "A19"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "9"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at -17.78 -25.4 0)
					(length 5.08)
					(name "Vcc"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "37"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at -17.78 -27.94 0)
					(length 5.08)
					(name "Vss"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "46"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at -17.78 -30.48 0)
					(length 5.08)
					(name "Vss"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "27"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin no_connect line
					(at -2.54 -38.1 90)
					(length 5.08)
					(hide yes)
					(name "NC"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "10"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin no_connect line
					(at 0 -38.1 90)
					(length 5.08)
					(hide yes)
					(name "NC"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "13"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 17.78 25.4 180)
					(length 5.08)
					(name "DQ0"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "29"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 17.78 22.86 180)
					(length 5.08)
					(name "DQ1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "31"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 17.78 20.32 180)
					(length 5.08)
					(name "DQ2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "33"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 17.78 17.78 180)
					(length 5.08)
					(name "DQ3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "35"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 17.78 15.24 180)
					(length 5.08)
					(name "DQ4"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "38"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 17.78 12.7 180)
					(length 5.08)
					(name "DQ5"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "40"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 17.78 10.16 180)
					(length 5.08)
					(name "DQ6"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "42"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 17.78 7.62 180)
					(length 5.08)
					(name "DQ7"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "44"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 17.78 5.08 180)
					(length 5.08)
					(name "DQ8"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "30"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 17.78 2.54 180)
					(length 5.08)
					(name "DQ9"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "32"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 17.78 0 180)
					(length 5.08)
					(name "DQ10"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "34"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 17.78 -2.54 180)
					(length 5.08)
					(name "DQ11"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "36"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 17.78 -5.08 180)
					(length 5.08)
					(name "DQ12"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "39"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 17.78 -7.62 180)
					(length 5.08)
					(name "DQ13"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "41"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 17.78 -10.16 180)
					(length 5.08)
					(name "DQ14"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "43"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 17.78 -12.7 180)
					(length 5.08)
					(name "DQ15/A20"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "45"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 17.78 -15.24 180)
					(length 5.08)
					(name "~{CE1}"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "26"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 17.78 -17.78 180)
					(length 5.08)
					(name "~{OE}"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "28"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 17.78 -20.32 180)
					(length 5.08)
					(name "~{WE}"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "11"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 17.78 -22.86 180)
					(length 5.08)
					(name "~{BYTE}"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "47"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 17.78 -25.4 180)
					(length 5.08)
					(name "~{BHE}"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "14"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 17.78 -27.94 180)
					(length 5.08)
					(name "~{BLE}"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "15"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 17.78 -30.48 180)
					(length 5.08)
					(name "CE2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "12"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
			(embedded_fonts no)
		)
		(symbol "MegaDriveCart:smd_cart_connector_edge"
			(pin_names
				(offset 1.016)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "CON"
				(at 0 17.78 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Value" "smd_cart_connector_edge"
				(at 0 -71.12 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" "Pinout for cartridge's edge connector"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "smd_cart_connector_edge_0_1"
				(rectangle
					(start -11.43 16.51)
					(end 11.43 -69.85)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type background)
					)
				)
			)
			(symbol "smd_cart_connector_edge_1_1"
				(pin output line
					(at -16.51 13.97 0)
					(length 5.08)
					(name "A0"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A17"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -16.51 11.43 0)
					(length 5.08)
					(name "A1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A15"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -16.51 8.89 0)
					(length 5.08)
					(name "A2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A13"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -16.51 6.35 0)
					(length 5.08)
					(name "A3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A11"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -16.51 3.81 0)
					(length 5.08)
					(name "A4"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A09"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -16.51 1.27 0)
					(length 5.08)
					(name "A5"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A07"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -16.51 -1.27 0)
					(length 5.08)
					(name "A6"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A05"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -16.51 -3.81 0)
					(length 5.08)
					(name "A7"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A03"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -16.51 -6.35 0)
					(length 5.08)
					(name "A8"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B04"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -16.51 -8.89 0)
					(length 5.08)
					(name "A9"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B05"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -16.51 -11.43 0)
					(length 5.08)
					(name "A10"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A04"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -16.51 -13.97 0)
					(length 5.08)
					(name "A11"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A06"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -16.51 -16.51 0)
					(length 5.08)
					(name "A12"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A08"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -16.51 -19.05 0)
					(length 5.08)
					(name "A13"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A10"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -16.51 -21.59 0)
					(length 5.08)
					(name "A14"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A12"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -16.51 -24.13 0)
					(length 5.08)
					(name "A15"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A14"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -16.51 -26.67 0)
					(length 5.08)
					(name "A16"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A16"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -16.51 -29.21 0)
					(length 5.08)
					(name "A17"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B06"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -16.51 -31.75 0)
					(length 5.08)
					(name "A18"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B07"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -16.51 -34.29 0)
					(length 5.08)
					(name "A19"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B08"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -16.51 -36.83 0)
					(length 5.08)
					(name "A20"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B09"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -16.51 -39.37 0)
					(length 5.08)
					(name "A21"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B10"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -16.51 -41.91 0)
					(length 5.08)
					(name "A22"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B11"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional inverted
					(at -16.51 -46.99 0)
					(length 5.08)
					(name "~{68K_RESET}"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B27"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output inverted
					(at -16.51 -49.53 0)
					(length 5.08)
					(name "~{LO_MEM}"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B26"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -16.51 -52.07 0)
					(length 5.08)
					(name "~{AS}"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B18"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output clock
					(at -16.51 -54.61 0)
					(length 5.08)
					(name "CLK"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B19"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_out line
					(at -16.51 -57.15 0)
					(length 5.08)
					(name "Vcc"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A02"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -16.51 -59.69 0)
					(length 5.08)
					(name "Vcc"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A31"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_out line
					(at -16.51 -62.23 0)
					(length 5.08)
					(name "GND"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A01"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -16.51 -64.77 0)
					(length 5.08)
					(name "GND"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A18"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -16.51 -67.31 0)
					(length 5.08)
					(name "GND"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A32"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 16.51 13.97 180)
					(length 5.08)
					(name "D0"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A20"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 16.51 11.43 180)
					(length 5.08)
					(name "D1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A23"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 16.51 8.89 180)
					(length 5.08)
					(name "D2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A26"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 16.51 6.35 180)
					(length 5.08)
					(name "D3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A29"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 16.51 3.81 180)
					(length 5.08)
					(name "D4"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A28"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 16.51 1.27 180)
					(length 5.08)
					(name "D5"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A25"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 16.51 -1.27 180)
					(length 5.08)
					(name "D6"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A22"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 16.51 -3.81 180)
					(length 5.08)
					(name "D7"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A19"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 16.51 -6.35 180)
					(length 5.08)
					(name "D8"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A21"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 16.51 -8.89 180)
					(length 5.08)
					(name "D9"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A24"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 16.51 -11.43 180)
					(length 5.08)
					(name "D10"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A27"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 16.51 -13.97 180)
					(length 5.08)
					(name "D11"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "A30"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 16.51 -16.51 180)
					(length 5.08)
					(name "D12"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B25"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 16.51 -19.05 180)
					(length 5.08)
					(name "D13"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B24"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 16.51 -21.59 180)
					(length 5.08)
					(name "D14"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B23"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 16.51 -24.13 180)
					(length 5.08)
					(name "D15"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B22"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output inverted
					(at 16.51 -29.21 180)
					(length 5.08)
					(name "~{LDSW}"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B28"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output inverted
					(at 16.51 -31.75 180)
					(length 5.08)
					(name "~{UDSW}"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B29"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 16.51 -34.29 180)
					(length 5.08)
					(name "~{CART_IN}"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B32"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output inverted
					(at 16.51 -36.83 180)
					(length 5.08)
					(name "~{C_OE}"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B16"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output inverted
					(at 16.51 -39.37 180)
					(length 5.08)
					(name "~{C_CE}"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B17"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input inverted
					(at 16.51 -41.91 180)
					(length 5.08)
					(name "~{DTACK}"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B20"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input inverted
					(at 16.51 -44.45 180)
					(length 5.08)
					(name "~{S_RESET}"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B30"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional inverted
					(at 16.51 -46.99 180)
					(length 5.08)
					(name "~{H_RESET}"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B02"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at 16.51 -49.53 180)
					(length 5.08)
					(name "VIDEO"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B12"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at 16.51 -52.07 180)
					(length 5.08)
					(name "VSYNC"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B13"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at 16.51 -54.61 180)
					(length 5.08)
					(name "HSYNC"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B14"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output clock
					(at 16.51 -57.15 180)
					(length 5.08)
					(name "HS_CLK"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B15"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin unspecified line
					(at 16.51 -59.69 180)
					(length 5.08)
					(name "SND_L"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B01"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin unspecified line
					(at 16.51 -62.23 180)
					(length 5.08)
					(name "SND_R"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B03"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output inverted
					(at 16.51 -64.77 180)
					(length 5.08)
					(name "~{CAS1}"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B21"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output inverted
					(at 16.51 -67.31 180)
					(length 5.08)
					(name "~{TIME}"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "B31"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
			(embedded_fonts no)
		)
		(symbol "Switch:SW_SPST"
			(pin_names
				(offset 0)
				(hide yes)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "SW"
				(at 0 3.175 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Value" "SW_SPST"
				(at 0 -2.54 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Datasheet" "~"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Description" "Single Pole Single Throw (SPST) switch"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_keywords" "switch lever"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "SW_SPST_0_0"
				(circle
					(center -2.032 0)
					(radius 0.508)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.524 0.254) (xy 1.524 1.778)
					)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(circle
					(center 2.032 0)
					(radius 0.508)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "SW_SPST_1_1"
				(pin passive line
					(at -5.08 0 0)
					(length 2.54)
					(name "A"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 0 180)
					(length 2.54)
					(name "B"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
			(embedded_fonts no)
		)
		(symbol "Switch:SW_Slide_DPDT"
			(pin_names
				(offset 0)
				(hide yes)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "SW"
				(at 0 6.858 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Value" "SW_Slide_DPDT"
				(at 0 -8.128 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 13.97 5.08 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Datasheet" "~"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Description" "Slide Switch, dual pole double throw"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_keywords" "switch dual-pole double-throw dpdt ON-ON"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "SW_Slide_DPDT_0_0"
				(circle
					(center -2.032 5.08)
					(radius 0.508)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(circle
					(center -2.032 -5.08)
					(radius 0.508)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(circle
					(center 2.032 0)
					(radius 0.508)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(circle
					(center 2.032 -5.08)
					(radius 0.508)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "SW_Slide_DPDT_0_1"
				(circle
					(center -2.032 0)
					(radius 0.508)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(circle
					(center 2.032 5.08)
					(radius 0.508)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "SW_Slide_DPDT_1_1"
				(rectangle
					(start -1.397 5.588)
					(end -0.762 -0.508)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type outline)
					)
				)
				(rectangle
					(start 0.762 5.588)
					(end 1.397 -0.508)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type outline)
					)
				)
				(pin passive line
					(at -5.08 5.08 0)
					(length 2.54)
					(name "A"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -5.08 0 0)
					(length 2.54)
					(name "B"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -5.08 -5.08 0)
					(length 2.54)
					(name "C"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 5.08 180)
					(length 2.54)
					(name "C"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "6"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 0 180)
					(length 2.54)
					(name "B"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "5"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 -5.08 180)
					(length 2.54)
					(name "A"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "4"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
			(embedded_fonts no)
		)
		(symbol "power:+5V"
			(power)
			(pin_numbers
				(hide yes)
			)
			(pin_names
				(offset 0)
				(hide yes)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "#PWR"
				(at 0 -3.81 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Value" "+5V"
				(at 0 3.556 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Description" "Power symbol creates a global label with name \"+5V\""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_keywords" "global power"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "+5V_0_1"
				(polyline
					(pts
						(xy -0.762 1.27) (xy 0 2.54)
					)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 2.54) (xy 0.762 1.27)
					)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 0) (xy 0 2.54)
					)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "+5V_1_1"
				(pin power_in line
					(at 0 0 90)
					(length 0)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
			(embedded_fonts no)
		)
		(symbol "power:GND"
			(power)
			(pin_numbers
				(hide yes)
			)
			(pin_names
				(offset 0)
				(hide yes)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "#PWR"
				(at 0 -6.35 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Value" "GND"
				(at 0 -3.81 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Description" "Power symbol creates a global label with name \"GND\" , ground"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_keywords" "global power"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "GND_0_1"
				(polyline
					(pts
						(xy 0 0) (xy 0 -1.27) (xy 1.27 -1.27) (xy 0 -2.54) (xy -1.27 -1.27) (xy 0 -1.27)
					)
					(stroke
						(width 0)
						(type default)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "GND_1_1"
				(pin power_in line
					(at 0 0 270)
					(length 0)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
			(embedded_fonts no)
		)
	)
	(junction
		(at 121.92 240.03)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "016e0b70-cfc5-4598-bd39-928b8e542a64")
	)
	(junction
		(at 34.29 177.8)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "08dfb55d-8605-45c0-a1cb-14306bcd82be")
	)
	(junction
		(at 34.29 220.98)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "1681b157-1485-4728-b5f3-f5e49dc862a7")
	)
	(junction
		(at 50.8 185.42)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "23f9174d-8d62-47d4-b143-d6db9f3adbc1")
	)
	(junction
		(at 71.12 246.38)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "26e1f653-c8dc-4d46-b6ba-de70f2526b65")
	)
	(junction
		(at 107.95 162.56)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "335cb029-8da3-4ef5-ab82-38fadda18c06")
	)
	(junction
		(at 160.02 154.94)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "35e4de9b-ae79-407f-90a4-b202a84ecd08")
	)
	(junction
		(at 50.8 177.8)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "395fcbe8-7739-44ac-b4e8-e61ba17f3e4d")
	)
	(junction
		(at 97.79 154.94)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "79838463-f847-4bfc-8d8b-0719eb80aa61")
	)
	(junction
		(at 160.02 232.41)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "8113d59c-5151-43e5-9d29-077dd764449b")
	)
	(junction
		(at 50.8 187.96)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "8cde13c2-7876-4711-85d6-266cf0fdc217")
	)
	(junction
		(at 121.92 162.56)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "99603a47-5da7-43ab-b9cf-0dcce388ba26")
	)
	(junction
		(at 107.95 234.95)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "99852395-882d-4020-b9a7-4d08d1c88b0e")
	)
	(junction
		(at 107.95 157.48)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "a1850725-082d-444b-a740-c475f4c61ae4")
	)
	(junction
		(at 160.02 234.95)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "a3499cd1-e2e3-452f-941f-f407cfbf2243")
	)
	(junction
		(at 50.8 255.27)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "a9c4d413-b195-4a86-b236-8fff52113bd7")
	)
	(junction
		(at 107.95 240.03)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "cc3d116f-6150-4c2e-8f97-6a29e7c3cfd8")
	)
	(junction
		(at 160.02 157.48)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "dc804494-e515-4b56-b916-2329334d31e1")
	)
	(junction
		(at 50.8 190.5)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "ef66daf9-52e6-4538-a911-da0aaf9e3068")
	)
	(no_connect
		(at 55.88 172.72)
		(uuid "17343bee-07e2-4742-82b1-276d790898b7")
	)
	(no_connect
		(at 157.48 214.63)
		(uuid "293582c8-15e5-4013-96e0-133b1c41d409")
	)
	(no_connect
		(at 157.48 137.16)
		(uuid "2aac7ea0-29aa-417c-95db-55e288ae2e23")
	)
	(no_connect
		(at 55.88 162.56)
		(uuid "2adc71cf-c330-4e43-994f-2aa9d03f7e0d")
	)
	(no_connect
		(at 88.9 180.34)
		(uuid "2d260d66-4668-44b8-982c-71996041c5ba")
	)
	(no_connect
		(at 88.9 162.56)
		(uuid "39b69dca-c4d7-4eca-a3a1-06c84eb407a9")
	)
	(no_connect
		(at 55.88 160.02)
		(uuid "3c20c618-1c06-445f-b25e-eb6ce058ae68")
	)
	(no_connect
		(at 157.48 219.71)
		(uuid "3e5f19ba-88eb-4da1-80b7-53f40acd0f2a")
	)
	(no_connect
		(at 157.48 217.17)
		(uuid "41a9471f-3d9a-4ef1-a02b-ebad8ceb4339")
	)
	(no_connect
		(at 157.48 212.09)
		(uuid "48e15e76-f315-4d6f-be08-5014ad014ead")
	)
	(no_connect
		(at 88.9 167.64)
		(uuid "4d467cdd-180e-4c5d-ba01-d30ca979b34f")
	)
	(no_connect
		(at 55.88 167.64)
		(uuid "4efb3a32-1092-412c-90b3-50b5a0a41fed")
	)
	(no_connect
		(at 88.9 185.42)
		(uuid "535c16ba-a83d-4284-a852-2dc4cdf46cdc")
	)
	(no_connect
		(at 88.9 172.72)
		(uuid "539d0317-953f-4600-935a-95b62e4557d8")
	)
	(no_connect
		(at 63.5 229.87)
		(uuid "5901f7c2-a08b-461e-a5ed-5dc5ef46f1dd")
	)
	(no_connect
		(at 157.48 142.24)
		(uuid "6aaa1efc-d152-44bc-8b36-38e7632b01ef")
	)
	(no_connect
		(at 88.9 187.96)
		(uuid "6aef17de-7142-4a5d-a885-18f6ad58a5aa")
	)
	(no_connect
		(at 157.48 139.7)
		(uuid "6bb76268-0ff9-40c2-a712-cc8dd091b45d")
	)
	(no_connect
		(at 157.48 134.62)
		(uuid "79da3ed5-d890-45c2-bb45-44424d2cde14")
	)
	(no_connect
		(at 157.48 127)
		(uuid "7c834103-5c94-4828-b3c6-5b1e031c69b0")
	)
	(no_connect
		(at 63.5 234.95)
		(uuid "91553c47-d160-40b1-a4ea-3a55bc1dbb4f")
	)
	(no_connect
		(at 88.9 175.26)
		(uuid "94d3fcee-aae6-4d01-8b52-74f8d8a00c79")
	)
	(no_connect
		(at 88.9 170.18)
		(uuid "97ed19b6-f1f4-429c-97c0-f3d6cb62913c")
	)
	(no_connect
		(at 157.48 207.01)
		(uuid "9fd59609-728d-48ad-b014-113abd84e10d")
	)
	(no_connect
		(at 88.9 182.88)
		(uuid "a8d72dcf-81ed-4a83-8452-9cd99550b1e8")
	)
	(no_connect
		(at 24.13 229.87)
		(uuid "b0f13124-608b-47d1-b24a-e6f8009ce8eb")
	)
	(no_connect
		(at 157.48 204.47)
		(uuid "b78a7f87-1138-4bd2-813c-df04b12038f5")
	)
	(no_connect
		(at 157.48 132.08)
		(uuid "cc9cb6c7-0ce7-4a81-961c-65fe72dc4fd6")
	)
	(no_connect
		(at 88.9 177.8)
		(uuid "d23e76d1-94db-443e-ac53-ee59ed5ab317")
	)
	(no_connect
		(at 157.48 209.55)
		(uuid "d2935f7d-59f1-43b8-a8f1-98ed15597510")
	)
	(no_connect
		(at 55.88 170.18)
		(uuid "d396663c-060d-46e0-aa79-9d85ada6ff00")
	)
	(no_connect
		(at 24.13 234.95)
		(uuid "d6c182f4-04fc-4d9c-a2aa-6fa452374b1b")
	)
	(no_connect
		(at 88.9 165.1)
		(uuid "e518f0cd-98f4-4b26-9e4d-900bc400e162")
	)
	(no_connect
		(at 55.88 175.26)
		(uuid "e66f774e-9ce3-4194-9a03-025bc37fb569")
	)
	(no_connect
		(at 157.48 129.54)
		(uuid "f6d9b01e-9be5-43d2-9d61-170233e68df1")
	)
	(bus_entry
		(at 113.03 109.22)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "020bf30c-5ece-4b02-b6ca-e5da8a3d963d")
	)
	(bus_entry
		(at 163.83 116.84)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "090c4b35-0ebf-451a-a27a-92a67b595ecd")
	)
	(bus_entry
		(at 163.83 119.38)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0d8a3527-e98e-4a83-83ec-dd462fa7873d")
	)
	(bus_entry
		(at 163.83 186.69)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0f098e56-37b4-40eb-87ad-46da8fe44007")
	)
	(bus_entry
		(at 113.03 149.86)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0f49791b-0e2b-4255-a70e-61ddc408ccca")
	)
	(bus_entry
		(at 163.83 184.15)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "12bbf573-d2ba-483e-bdc4-d797f418d7dd")
	)
	(bus_entry
		(at 95.25 124.46)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1540af48-ee96-4727-9e48-dde1e9dce4a9")
	)
	(bus_entry
		(at 163.83 111.76)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "180b3ae7-b5fa-49bc-bfe4-bbfb938964b1")
	)
	(bus_entry
		(at 46.99 149.86)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1a1825d8-36bc-4a2d-86cc-4fbf2039bab4")
	)
	(bus_entry
		(at 113.03 114.3)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1d26bc57-9e9d-413e-9a02-1391f25af9da")
	)
	(bus_entry
		(at 95.25 139.7)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1dc28145-899b-4aeb-9969-2355f267ee8d")
	)
	(bus_entry
		(at 113.03 181.61)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1e16caf1-c9ab-4e6e-9df6-47fe83ee638f")
	)
	(bus_entry
		(at 163.83 121.92)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1fb2616d-5f83-403c-8758-d0ced9068bce")
	)
	(bus_entry
		(at 113.03 201.93)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "22221948-9937-44ab-947f-265ec7828ff3")
	)
	(bus_entry
		(at 113.03 152.4)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "27760e0f-1cd7-48c9-8a54-b62a3e698cf6")
	)
	(bus_entry
		(at 163.83 124.46)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "29ed8a97-da73-4398-890e-6a3ee9e0654c")
	)
	(bus_entry
		(at 113.03 191.77)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2a6994e6-03b5-44e8-a71e-f4a3510cb5dd")
	)
	(bus_entry
		(at 163.83 222.25)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2b1f843b-f9df-4910-b364-52a759d7feaf")
	)
	(bus_entry
		(at 95.25 111.76)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "33c154c9-4936-4e60-8d0e-af17f7d2d5e4")
	)
	(bus_entry
		(at 46.99 109.22)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "34d3fc2c-4283-4bbd-a328-9365ec30b4d2")
	)
	(bus_entry
		(at 163.83 196.85)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3780ad46-b3e5-4dae-9fbe-51c563eda200")
	)
	(bus_entry
		(at 113.03 129.54)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "38944482-6f2a-42ef-97ce-de3bbcca2eac")
	)
	(bus_entry
		(at 113.03 116.84)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3941076c-0cf3-4991-b7e2-6378105df8ad")
	)
	(bus_entry
		(at 113.03 189.23)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "39787abb-e9c3-49f1-a39d-daca842acefe")
	)
	(bus_entry
		(at 113.03 147.32)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3d87927c-4c20-482e-a0e1-3562b42486f3")
	)
	(bus_entry
		(at 163.83 109.22)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3fadb699-d41f-49a5-b864-af7be4cfa8d9")
	)
	(bus_entry
		(at 46.99 104.14)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3fbd97c7-11da-4ec5-8f78-c65d28d4f6cc")
	)
	(bus_entry
		(at 95.25 142.24)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "41567b8b-ad4d-4add-ac8d-7056b3f6ad58")
	)
	(bus_entry
		(at 95.25 137.16)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "418d9f69-1c16-47fb-9875-64143236c1bf")
	)
	(bus_entry
		(at 46.99 106.68)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "41f42d09-f5a9-4daa-b508-93d5703d0831")
	)
	(bus_entry
		(at 163.83 144.78)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "469887a3-33cf-474a-9061-e3228c89ed35")
	)
	(bus_entry
		(at 113.03 104.14)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "469d7246-e6e8-4937-b875-d42f6c886652")
	)
	(bus_entry
		(at 95.25 134.62)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "46d928bb-a32b-4392-9733-f19f3219c0e2")
	)
	(bus_entry
		(at 113.03 222.25)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4d3bbee9-d68d-4d44-9ee9-d49b8aae6426")
	)
	(bus_entry
		(at 113.03 144.78)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5300d3fb-b9dc-446c-a36e-e016ac04ed48")
	)
	(bus_entry
		(at 113.03 227.33)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "54a7e0f6-ff11-449b-8d78-6c5f776c6507")
	)
	(bus_entry
		(at 95.25 119.38)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "577b03a1-404a-4e0b-87b7-fc602cc4e2a7")
	)
	(bus_entry
		(at 46.99 142.24)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "58150828-91a5-407b-8b0b-6699daa21ec5")
	)
	(bus_entry
		(at 113.03 207.01)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5a6c2b31-8f00-44eb-ace3-40fcd80ebf1b")
	)
	(bus_entry
		(at 95.25 127)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5f384487-76f9-4b93-bbbf-0fae98e3e27b")
	)
	(bus_entry
		(at 46.99 119.38)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "615a1eb6-ebde-451c-b741-5f161c74203a")
	)
	(bus_entry
		(at 163.83 199.39)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "61fb8c8a-c6fb-4710-b285-d9764a2725db")
	)
	(bus_entry
		(at 95.25 116.84)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6a780ca0-1f8d-4531-876d-ad51a563c8dc")
	)
	(bus_entry
		(at 113.03 106.68)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6c6259d4-957d-46b3-a5e8-c3654fc39975")
	)
	(bus_entry
		(at 163.83 191.77)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6e7429fd-3a52-4a64-90e6-03e91497dc56")
	)
	(bus_entry
		(at 113.03 214.63)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7271a367-dbce-41da-aae9-1d102019ab34")
	)
	(bus_entry
		(at 95.25 109.22)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7384a325-666d-4884-a6d0-ac1908041250")
	)
	(bus_entry
		(at 46.99 137.16)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "74ee569a-b0cd-4312-b690-bae4108730ea")
	)
	(bus_entry
		(at 113.03 137.16)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "79a66178-95c2-421e-9be8-3fd0e16944e5")
	)
	(bus_entry
		(at 113.03 196.85)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7a4e2e36-f2b8-4547-8eae-6f94ddd3653d")
	)
	(bus_entry
		(at 46.99 154.94)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7ae64d6e-dea5-4506-86d0-0a726e612b05")
	)
	(bus_entry
		(at 46.99 116.84)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7c05b1e1-4042-4eca-b93b-08ec19ef07e5")
	)
	(bus_entry
		(at 113.03 186.69)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "816c585a-d0b8-4067-99cf-896083298d38")
	)
	(bus_entry
		(at 163.83 189.23)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "87a1f843-abd2-45b1-869b-18b318259fac")
	)
	(bus_entry
		(at 46.99 134.62)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "881fd7b7-8935-4344-a9ae-34be5d7eeb76")
	)
	(bus_entry
		(at 113.03 184.15)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8d7b4c18-8dcf-400b-a14e-a77e44f26525")
	)
	(bus_entry
		(at 113.03 142.24)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "93547569-97e9-4c07-a6c8-81664866d02a")
	)
	(bus_entry
		(at 95.25 144.78)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "95e27682-95ef-4008-bc3e-5faf03ac8a5d")
	)
	(bus_entry
		(at 113.03 124.46)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "98d9a820-d012-4b35-9a4c-cdfd2a3f7301")
	)
	(bus_entry
		(at 46.99 152.4)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9e0140e4-992e-4049-ab1e-301710658ea3")
	)
	(bus_entry
		(at 46.99 124.46)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9f700901-67fc-4355-8323-f75ee67fff49")
	)
	(bus_entry
		(at 113.03 111.76)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9fbc08d6-20a5-42fd-adc7-d4256a4a7b90")
	)
	(bus_entry
		(at 95.25 129.54)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a1c6ffcc-542c-4605-8147-802055ae5a1f")
	)
	(bus_entry
		(at 113.03 229.87)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a382f075-bf8d-4982-a09b-5668af6e9ec1")
	)
	(bus_entry
		(at 95.25 121.92)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a5600548-ac55-4ded-bf06-0abfbee9556f")
	)
	(bus_entry
		(at 46.99 129.54)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ad8eb832-4c9e-4de8-899a-66b22de32247")
	)
	(bus_entry
		(at 113.03 204.47)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b05b0b68-5932-4df0-9b0e-880032ec34d0")
	)
	(bus_entry
		(at 113.03 212.09)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b0ab28b6-3e11-41a5-a269-0a94d148fd38")
	)
	(bus_entry
		(at 163.83 194.31)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b855966e-086d-442f-b56b-90ed5b0bebbe")
	)
	(bus_entry
		(at 46.99 121.92)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b9ea16b2-13c8-45b8-a150-1616aec9b6eb")
	)
	(bus_entry
		(at 113.03 134.62)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bdffdc90-ee3a-463a-84c1-da562a6b5819")
	)
	(bus_entry
		(at 46.99 144.78)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bf15ca0a-43e9-4322-8fc6-62f5576fcaf6")
	)
	(bus_entry
		(at 113.03 209.55)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c4db0eef-41d2-4336-8a5e-4b70f9500d02")
	)
	(bus_entry
		(at 95.25 132.08)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cc9bc64b-e472-49ee-a3d3-2ba63e772b6e")
	)
	(bus_entry
		(at 113.03 217.17)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d0046318-1d3e-4be2-bc6e-2ad7dd2b41d2")
	)
	(bus_entry
		(at 113.03 127)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d00b9f6f-41bb-441b-90da-057cb85f663d")
	)
	(bus_entry
		(at 113.03 219.71)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d3dd1623-fda7-4e82-aef6-5694b261ba29")
	)
	(bus_entry
		(at 46.99 127)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d413d49a-e554-4c8e-b3a4-c7f47c38cba0")
	)
	(bus_entry
		(at 46.99 111.76)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d922db41-c856-4561-83f8-f631741ce68d")
	)
	(bus_entry
		(at 46.99 139.7)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d9457a71-bb64-4b41-9c56-604f5228f2a4")
	)
	(bus_entry
		(at 113.03 132.08)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "db0fc2e8-72ec-45ac-92eb-f9bfd43888af")
	)
	(bus_entry
		(at 95.25 114.3)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "dc1f37fa-0537-4afb-a701-73785f09f859")
	)
	(bus_entry
		(at 113.03 194.31)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "df488340-2b1e-4804-8696-737feefaa1ea")
	)
	(bus_entry
		(at 113.03 224.79)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e879b086-4c73-4372-8478-b698a32deede")
	)
	(bus_entry
		(at 163.83 106.68)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e9693b8e-5950-4c12-aa7c-9b47fa0eb19b")
	)
	(bus_entry
		(at 95.25 106.68)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "eae864bb-10f8-4057-9301-ead5a0ec73fc")
	)
	(bus_entry
		(at 113.03 119.38)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "eafa1f60-d85e-4243-9190-1600656a7f76")
	)
	(bus_entry
		(at 113.03 199.39)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ebbe84f2-1208-4ab7-a295-25668d9a4aae")
	)
	(bus_entry
		(at 46.99 114.3)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "efc77232-4f2d-4cce-8881-a8c9e3146c51")
	)
	(bus_entry
		(at 113.03 139.7)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f120ca58-c532-4215-b543-9eedfe4ea228")
	)
	(bus_entry
		(at 163.83 201.93)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f373a60f-2c6b-4f72-b967-ae98615cecdb")
	)
	(bus_entry
		(at 46.99 132.08)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f9911d9a-e86d-4edc-8d55-10be97895f13")
	)
	(bus_entry
		(at 163.83 114.3)
		(size 2.54 -2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "fae9d329-e914-46d0-9d1e-f3a084173502")
	)
	(bus_entry
		(at 113.03 121.92)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "fd1e1bc5-8bbd-4739-b1ee-30d9a7db9088")
	)
	(bus_entry
		(at 46.99 147.32)
		(size 2.54 2.54)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "fd9e115a-d181-4055-a267-29b05e51642e")
	)
	(bus
		(pts
			(xy 46.99 134.62) (xy 46.99 137.16)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "01b25593-f105-466d-8d58-b3a89bfcfe7a")
	)
	(wire
		(pts
			(xy 157.48 201.93) (xy 163.83 201.93)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "020e63bd-4220-4425-9d87-f420bb320f60")
	)
	(wire
		(pts
			(xy 54.61 190.5) (xy 50.8 190.5)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0302e728-153a-4317-ba12-cfbbdc5db070")
	)
	(bus
		(pts
			(xy 46.99 129.54) (xy 46.99 132.08)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "034e3599-01ed-4369-a2bb-899061804e07")
	)
	(wire
		(pts
			(xy 157.48 160.02) (xy 160.02 160.02)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "060f095b-a4e1-4cd6-9e40-49061cc1aae1")
	)
	(wire
		(pts
			(xy 157.48 191.77) (xy 163.83 191.77)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "06ac5e58-44c9-4b76-81ba-76d5130cfeb1")
	)
	(bus
		(pts
			(xy 166.37 104.14) (xy 166.37 106.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "07db428d-d5d6-403f-b6cd-1ef66279dce7")
	)
	(bus
		(pts
			(xy 46.99 104.14) (xy 46.99 106.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "08659d9c-50bc-43e8-b5f7-264d794466d8")
	)
	(wire
		(pts
			(xy 160.02 157.48) (xy 160.02 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "09b69beb-1931-41ec-b998-3f8067eee45f")
	)
	(wire
		(pts
			(xy 161.29 224.79) (xy 157.48 224.79)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "09f58014-4df7-4809-8283-dce1b95229f1")
	)
	(bus
		(pts
			(xy 97.79 119.38) (xy 97.79 121.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0b52d1c7-ffee-4ecf-af7e-042e03af0c19")
	)
	(wire
		(pts
			(xy 90.17 246.38) (xy 90.17 204.47)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0bfc8729-736e-4aca-a883-faab7b31e20e")
	)
	(bus
		(pts
			(xy 113.03 199.39) (xy 113.03 201.93)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0dd9cb75-e001-4f64-bb03-3a10e462d125")
	)
	(wire
		(pts
			(xy 50.8 190.5) (xy 50.8 194.31)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0fd820ba-c242-4bee-b5d6-97ccdcb1b128")
	)
	(wire
		(pts
			(xy 49.53 154.94) (xy 55.88 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "10e09739-5baa-4bc9-b3cd-65e547dee8b4")
	)
	(wire
		(pts
			(xy 49.53 114.3) (xy 55.88 114.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "111e98ce-8c5a-4956-911d-55035d3d07a5")
	)
	(bus
		(pts
			(xy 113.03 227.33) (xy 113.03 229.87)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "11874700-5756-4232-8b98-31a09a178dcc")
	)
	(wire
		(pts
			(xy 49.53 119.38) (xy 55.88 119.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "12496c86-58a3-4cfc-98cc-1f23e7716ed1")
	)
	(wire
		(pts
			(xy 115.57 109.22) (xy 121.92 109.22)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "130cdcdf-b024-424c-8f1f-e282df97d719")
	)
	(bus
		(pts
			(xy 113.03 121.92) (xy 113.03 124.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "13eebead-d165-4219-9b09-824c339d0fe4")
	)
	(bus
		(pts
			(xy 113.03 189.23) (xy 113.03 191.77)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "13f4d2da-b9d9-4308-9703-309e758aa73b")
	)
	(wire
		(pts
			(xy 49.53 111.76) (xy 55.88 111.76)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "141d061b-9639-4356-88d4-591cecb7f201")
	)
	(wire
		(pts
			(xy 34.29 220.98) (xy 73.66 220.98)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "15b035e6-c6c0-4974-b5a3-a799c9943e98")
	)
	(bus
		(pts
			(xy 113.03 209.55) (xy 113.03 212.09)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "168f6e71-796d-475c-9670-244e2fea2077")
	)
	(wire
		(pts
			(xy 19.05 232.41) (xy 24.13 232.41)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "16d9cb66-6605-40fb-9b8b-0950e9df99a0")
	)
	(wire
		(pts
			(xy 115.57 191.77) (xy 121.92 191.77)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "16fa89a4-0a26-48cf-b947-98c0c5dc4650")
	)
	(bus
		(pts
			(xy 46.99 100.33) (xy 46.99 104.14)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "19b75474-a242-4fa6-a759-96a37b917129")
	)
	(bus
		(pts
			(xy 113.03 191.77) (xy 113.03 194.31)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1b48f66e-f87f-4231-a296-ee4035d9f284")
	)
	(bus
		(pts
			(xy 46.99 109.22) (xy 46.99 111.76)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1df0af64-8bcb-4879-886d-aaaac53f5a6b")
	)
	(bus
		(pts
			(xy 166.37 119.38) (xy 166.37 121.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1e095e57-6af5-4b9f-954f-6c048e82f585")
	)
	(wire
		(pts
			(xy 34.29 177.8) (xy 50.8 177.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2075cab7-81ab-4c6e-bd3d-106f4080ce06")
	)
	(bus
		(pts
			(xy 113.03 100.33) (xy 113.03 104.14)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "21208033-f452-4a50-9fe8-766d3de97685")
	)
	(wire
		(pts
			(xy 157.48 229.87) (xy 161.29 229.87)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2170f488-6cd3-4f98-bd1a-c1946e2ee591")
	)
	(bus
		(pts
			(xy 113.03 149.86) (xy 113.03 152.4)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "21a4e77f-d819-45eb-9cc7-9383b7b09384")
	)
	(bus
		(pts
			(xy 113.03 201.93) (xy 113.03 204.47)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "227bce65-ccf2-4019-a16d-7b62cb52d15d")
	)
	(wire
		(pts
			(xy 49.53 157.48) (xy 55.88 157.48)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "24df7972-d9b9-4068-b136-6709efcee935")
	)
	(wire
		(pts
			(xy 115.57 116.84) (xy 121.92 116.84)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "260b588f-d341-4408-b5c9-806eb11d654f")
	)
	(wire
		(pts
			(xy 57.15 271.78) (xy 60.96 271.78)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2636d54b-2955-4230-bcbe-396a9eee6142")
	)
	(bus
		(pts
			(xy 46.99 106.68) (xy 46.99 109.22)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2665f270-8bb0-41dc-a286-14f4014d87ec")
	)
	(wire
		(pts
			(xy 78.74 232.41) (xy 82.55 232.41)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "27c22542-0670-4976-a6b6-357337d2669d")
	)
	(wire
		(pts
			(xy 88.9 139.7) (xy 95.25 139.7)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "27df40cc-d63b-4182-87a2-2c00677d7c30")
	)
	(wire
		(pts
			(xy 34.29 276.86) (xy 46.99 276.86)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "286c1c84-e168-4b1f-8e68-b95b087c2b41")
	)
	(bus
		(pts
			(xy 113.03 109.22) (xy 113.03 111.76)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2a5106bd-ecd3-4453-8eb6-04a2ea3fd867")
	)
	(bus
		(pts
			(xy 97.79 104.14) (xy 97.79 106.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2db38333-1b98-439d-b35d-98a543c8884f")
	)
	(wire
		(pts
			(xy 107.95 157.48) (xy 121.92 157.48)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2de6d355-e30d-498e-9a54-217bb9bd4727")
	)
	(wire
		(pts
			(xy 50.8 185.42) (xy 50.8 187.96)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2e15b506-c615-453a-a6f4-bba39294f835")
	)
	(wire
		(pts
			(xy 72.39 271.78) (xy 68.58 271.78)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2e31ac16-905d-4f0e-adee-78d78a29a02f")
	)
	(wire
		(pts
			(xy 88.9 124.46) (xy 95.25 124.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2e32ead1-79d2-47d0-8a11-0c17d981ffd2")
	)
	(bus
		(pts
			(xy 113.03 124.46) (xy 113.03 127)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2f66c002-7319-4cfe-9838-1cd87c3e829d")
	)
	(wire
		(pts
			(xy 115.57 196.85) (xy 121.92 196.85)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2fc62a6a-ee84-4334-8d55-e4b955e62a17")
	)
	(bus
		(pts
			(xy 113.03 204.47) (xy 113.03 207.01)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3022e1c6-615e-4fad-abc2-d8104b248ec4")
	)
	(wire
		(pts
			(xy 71.12 240.03) (xy 71.12 246.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3085ca35-0ac4-405d-b731-ecff206e5f4c")
	)
	(bus
		(pts
			(xy 113.03 134.62) (xy 113.03 137.16)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "31c4c651-9fd9-41bd-8ae5-24637d3c27ce")
	)
	(bus
		(pts
			(xy 113.03 184.15) (xy 113.03 186.69)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "31d9120d-7744-4ad5-adaf-5f3f143b68b3")
	)
	(wire
		(pts
			(xy 88.9 142.24) (xy 95.25 142.24)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "32b6f53e-f290-4518-9249-bcca9612c1bf")
	)
	(wire
		(pts
			(xy 34.29 271.78) (xy 36.83 271.78)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "35d3b85b-7f40-42b9-9e2a-5d6ea1acad93")
	)
	(bus
		(pts
			(xy 97.79 100.33) (xy 97.79 104.14)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3602bc52-6cb9-4d2f-81d7-c0ffaffe2929")
	)
	(wire
		(pts
			(xy 163.83 222.25) (xy 157.48 222.25)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "36407cc2-adee-41c4-bed7-109b0240e961")
	)
	(wire
		(pts
			(xy 58.42 232.41) (xy 63.5 232.41)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "36910425-5489-4004-ba6c-a8204d2f2b82")
	)
	(bus
		(pts
			(xy 113.03 132.08) (xy 113.03 134.62)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "370f8466-52da-4983-ba39-22f0a434ac06")
	)
	(wire
		(pts
			(xy 88.9 132.08) (xy 95.25 132.08)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "38e1018c-913e-427e-82c4-433c6fe67af9")
	)
	(wire
		(pts
			(xy 115.57 224.79) (xy 121.92 224.79)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3afd2450-6094-4a85-996e-dbf3b9ed225e")
	)
	(wire
		(pts
			(xy 121.92 162.56) (xy 107.95 162.56)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3b917142-1379-4e88-a279-acb5ec8132d7")
	)
	(wire
		(pts
			(xy 115.57 152.4) (xy 121.92 152.4)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3c270ac0-acb0-4540-a24e-0afd99573f60")
	)
	(wire
		(pts
			(xy 157.48 232.41) (xy 160.02 232.41)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3c9ae91c-9cfd-488c-940b-6e05b00d0cc5")
	)
	(bus
		(pts
			(xy 97.79 109.22) (xy 97.79 111.76)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3ef9a2b9-fac1-41c8-a912-d6227f01fc04")
	)
	(wire
		(pts
			(xy 88.9 116.84) (xy 95.25 116.84)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3f1298fc-f7c4-4a22-9039-ca896f5c6206")
	)
	(wire
		(pts
			(xy 160.02 160.02) (xy 160.02 157.48)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3f17e116-40b7-436e-84e8-024188e7a6d3")
	)
	(wire
		(pts
			(xy 55.88 185.42) (xy 50.8 185.42)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "41356d80-0d42-49bb-bde3-7c425177b4f6")
	)
	(wire
		(pts
			(xy 157.48 121.92) (xy 163.83 121.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "41789523-acbb-456b-986b-df7e4cd201af")
	)
	(bus
		(pts
			(xy 97.79 129.54) (xy 97.79 132.08)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "41cb17cd-85a6-4281-9447-060dea5a1671")
	)
	(wire
		(pts
			(xy 55.88 182.88) (xy 50.8 182.88)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4296fb67-66d2-45a9-b1c1-8eeee349cbbb")
	)
	(bus
		(pts
			(xy 166.37 111.76) (xy 166.37 114.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "43c62797-6123-4124-85d4-b1820802c888")
	)
	(wire
		(pts
			(xy 115.57 212.09) (xy 121.92 212.09)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "452956b4-4cda-4213-afcc-bd2e0c6c8121")
	)
	(wire
		(pts
			(xy 54.61 201.93) (xy 54.61 190.5)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "46ffce1b-b2da-4f2c-a001-561736abc8ea")
	)
	(wire
		(pts
			(xy 115.57 132.08) (xy 121.92 132.08)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "474819c3-3547-4af5-bd1f-bfd47758676c")
	)
	(wire
		(pts
			(xy 115.57 127) (xy 121.92 127)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4801207e-4436-4581-9ec1-9e50ea8ea893")
	)
	(wire
		(pts
			(xy 77.47 201.93) (xy 97.79 201.93)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "486c8f2c-5d20-48fa-ae81-7e93f35fca58")
	)
	(bus
		(pts
			(xy 46.99 149.86) (xy 46.99 152.4)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "49f0150e-0fcf-41df-ab28-91a206320294")
	)
	(wire
		(pts
			(xy 50.8 182.88) (xy 50.8 185.42)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4a0c8eec-d6ba-4861-9889-87baba17f21d")
	)
	(wire
		(pts
			(xy 71.12 246.38) (xy 90.17 246.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4a58edfb-bde5-4995-a44c-d675416c34f8")
	)
	(wire
		(pts
			(xy 157.48 154.94) (xy 160.02 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4b149895-f9ae-46e7-b06b-3de7ca4b9a87")
	)
	(wire
		(pts
			(xy 157.48 119.38) (xy 163.83 119.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4b802066-9e0d-4306-9692-7581e99571e9")
	)
	(bus
		(pts
			(xy 97.79 137.16) (xy 97.79 139.7)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4b92bd2f-be55-4bda-80da-b2eeb6d8f10e")
	)
	(bus
		(pts
			(xy 46.99 142.24) (xy 46.99 144.78)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4df4d26d-1a73-469b-a6c0-9c7dccd80c8b")
	)
	(bus
		(pts
			(xy 113.03 207.01) (xy 113.03 209.55)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4e59641f-33ad-47cf-92af-519ad2e6fcc3")
	)
	(wire
		(pts
			(xy 157.48 152.4) (xy 161.29 152.4)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4e687c53-a9f3-435d-8862-3ec57e028a58")
	)
	(bus
		(pts
			(xy 166.37 116.84) (xy 166.37 119.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4e744775-14ef-4864-a3ff-b6ccbbed9a64")
	)
	(wire
		(pts
			(xy 115.57 139.7) (xy 121.92 139.7)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4e79141d-1c18-47d7-a0f4-b12f723c8a74")
	)
	(wire
		(pts
			(xy 49.53 121.92) (xy 55.88 121.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4fee0d76-edd5-46dc-94c5-99b008aa6943")
	)
	(bus
		(pts
			(xy 97.79 127) (xy 97.79 129.54)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5097cdcb-1eb6-4438-b5a6-2fad501a378a")
	)
	(bus
		(pts
			(xy 166.37 191.77) (xy 166.37 194.31)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "50afc979-ac20-4723-a1a9-f7733bc19ad4")
	)
	(wire
		(pts
			(xy 115.57 111.76) (xy 121.92 111.76)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "51106c19-043e-44d2-9407-1598f0ef3e60")
	)
	(wire
		(pts
			(xy 105.41 234.95) (xy 107.95 234.95)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "519e0145-fc45-4e24-ae20-680baf32e52e")
	)
	(wire
		(pts
			(xy 50.8 187.96) (xy 50.8 190.5)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "54720f79-3c4e-49be-a8e1-2352bf1e0a8e")
	)
	(bus
		(pts
			(xy 97.79 106.68) (xy 97.79 109.22)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "558b93bc-8771-4ca9-9304-b6fb551bf43d")
	)
	(bus
		(pts
			(xy 166.37 106.68) (xy 166.37 109.22)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "57fd4da9-dd35-46d6-8bfd-c2a9b2ec71b9")
	)
	(wire
		(pts
			(xy 115.57 137.16) (xy 121.92 137.16)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "58695fe1-7f06-4068-bf26-fd45fb3b8150")
	)
	(wire
		(pts
			(xy 88.9 114.3) (xy 95.25 114.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "59f03aab-fdd8-4ceb-a783-fea7ba836cea")
	)
	(wire
		(pts
			(xy 50.8 255.27) (xy 73.66 255.27)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5acb5981-49a7-406d-96c6-ce179ee9abc8")
	)
	(wire
		(pts
			(xy 88.9 111.76) (xy 95.25 111.76)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5c267140-df8c-4d2c-9083-7a01d0ede98f")
	)
	(bus
		(pts
			(xy 46.99 114.3) (xy 46.99 116.84)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5cb5198c-400a-4415-a85d-298997ba8d1c")
	)
	(wire
		(pts
			(xy 115.57 201.93) (xy 121.92 201.93)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5d6eace1-9eec-410f-8d78-3c7d18c49de7")
	)
	(bus
		(pts
			(xy 166.37 177.8) (xy 166.37 181.61)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5dd910fa-8144-49c1-bf65-e83a19b44619")
	)
	(wire
		(pts
			(xy 115.57 186.69) (xy 121.92 186.69)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5e85f867-4c2f-422b-a531-85d6ca01b019")
	)
	(wire
		(pts
			(xy 115.57 119.38) (xy 121.92 119.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5f2cc1e6-76d3-4c03-9b51-d3e0ec8f912a")
	)
	(wire
		(pts
			(xy 49.53 137.16) (xy 55.88 137.16)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "606beec5-ad60-40c3-bd93-590c4a5197af")
	)
	(wire
		(pts
			(xy 115.57 204.47) (xy 121.92 204.47)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "610a4615-1452-4f92-ab60-dd35f84d2261")
	)
	(wire
		(pts
			(xy 157.48 106.68) (xy 163.83 106.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "61bb1405-59ac-497e-b87d-4779a7e331b4")
	)
	(wire
		(pts
			(xy 88.9 119.38) (xy 95.25 119.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "62c0a131-acec-47f8-b359-66b3fd3848e7")
	)
	(wire
		(pts
			(xy 157.48 237.49) (xy 160.02 237.49)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "650cc2aa-2db2-4fd3-9dbf-0deee52b509a")
	)
	(wire
		(pts
			(xy 97.79 154.94) (xy 88.9 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6585453f-c25e-4798-8eeb-17c70f5978af")
	)
	(wire
		(pts
			(xy 121.92 237.49) (xy 121.92 240.03)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6678a13f-4a65-4cc2-bea5-8920424fb682")
	)
	(wire
		(pts
			(xy 105.41 157.48) (xy 107.95 157.48)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "67f6d059-94f3-478e-9d3e-0ff6d7a34412")
	)
	(wire
		(pts
			(xy 157.48 186.69) (xy 163.83 186.69)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6a320179-f1f0-43dd-8b1a-bf98c3cf5417")
	)
	(wire
		(pts
			(xy 73.66 220.98) (xy 73.66 224.79)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6ae67e4b-2ff5-4003-829b-babe8c4f6c17")
	)
	(wire
		(pts
			(xy 177.8 232.41) (xy 177.8 240.03)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6afc531d-f83c-46c7-b992-cb1c81679dc8")
	)
	(wire
		(pts
			(xy 121.92 106.68) (xy 115.57 106.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6b82250a-105b-4357-bfd7-3c53a41e7f82")
	)
	(bus
		(pts
			(xy 113.03 116.84) (xy 113.03 119.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6c15a641-71f0-4101-b86d-1b1d768da2ae")
	)
	(wire
		(pts
			(xy 160.02 237.49) (xy 160.02 234.95)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6c76cf93-543a-42b8-b66e-02b2a2ebd628")
	)
	(wire
		(pts
			(xy 97.79 154.94) (xy 97.79 153.67)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6f8b03b6-34ba-4286-8f8f-143b04b1ca7b")
	)
	(bus
		(pts
			(xy 113.03 142.24) (xy 113.03 144.78)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6fda4f51-753d-4740-9b48-0c44a6877b72")
	)
	(bus
		(pts
			(xy 46.99 147.32) (xy 46.99 149.86)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7134b97d-3ef1-4a86-b0ad-96b8db2a8102")
	)
	(wire
		(pts
			(xy 115.57 229.87) (xy 121.92 229.87)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "72f31814-d219-401d-b91e-4896d665da78")
	)
	(wire
		(pts
			(xy 115.57 121.92) (xy 121.92 121.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "743a5ee2-78a2-4fdf-b1c5-8ffe56230045")
	)
	(bus
		(pts
			(xy 113.03 119.38) (xy 113.03 121.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "74fcd8ee-e9d3-487d-aec7-722537086783")
	)
	(wire
		(pts
			(xy 157.48 114.3) (xy 163.83 114.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7680de1a-d715-4138-9049-6c08140546e0")
	)
	(wire
		(pts
			(xy 31.75 246.38) (xy 71.12 246.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "77849565-5f95-44d3-8118-8ceaed7b520c")
	)
	(bus
		(pts
			(xy 113.03 222.25) (xy 113.03 224.79)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "78eaa7ef-f191-4ba5-88f8-0f9b65c6852a")
	)
	(wire
		(pts
			(xy 115.57 209.55) (xy 121.92 209.55)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "792d7d4f-2398-4249-b275-aae84e46f757")
	)
	(wire
		(pts
			(xy 157.48 227.33) (xy 161.29 227.33)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7a4c7620-d120-4c4f-b1cc-0dd07f3b5576")
	)
	(wire
		(pts
			(xy 121.92 184.15) (xy 115.57 184.15)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7ae183ac-93c5-4852-bebd-133eef8000d8")
	)
	(wire
		(pts
			(xy 115.57 149.86) (xy 121.92 149.86)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7ae9d8b3-c244-4536-82d2-a771982c165b")
	)
	(wire
		(pts
			(xy 115.57 189.23) (xy 121.92 189.23)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7c0ab614-8f7d-4360-b2fe-22565890c497")
	)
	(bus
		(pts
			(xy 46.99 119.38) (xy 46.99 121.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7d48af87-d04f-4525-a1b8-617c4de3d272")
	)
	(wire
		(pts
			(xy 157.48 196.85) (xy 163.83 196.85)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7dc6dc3a-a973-4c1b-aa8f-f54e7eef7758")
	)
	(bus
		(pts
			(xy 113.03 214.63) (xy 113.03 217.17)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7e4327cb-48d8-4c60-93e3-28fac0d51490")
	)
	(wire
		(pts
			(xy 34.29 224.79) (xy 34.29 220.98)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "80a798f5-6ba3-4325-99e5-7158a49e6479")
	)
	(wire
		(pts
			(xy 115.57 144.78) (xy 121.92 144.78)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8142c0f1-f84c-4993-8fc0-cbdf6043b17a")
	)
	(wire
		(pts
			(xy 44.45 271.78) (xy 46.99 271.78)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "81a3131c-0e74-45c7-94ef-b2c1d9763231")
	)
	(bus
		(pts
			(xy 166.37 109.22) (xy 166.37 111.76)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "81a782c3-f078-43ed-91b7-2532dcd3598f")
	)
	(bus
		(pts
			(xy 166.37 181.61) (xy 166.37 184.15)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "83410f35-533a-4b34-b281-4e18b7a36ac8")
	)
	(wire
		(pts
			(xy 115.57 194.31) (xy 121.92 194.31)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8385a07f-8c41-4dfa-832f-75ac29f20b7a")
	)
	(wire
		(pts
			(xy 107.95 234.95) (xy 121.92 234.95)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "83af4fe7-ba37-4fad-b937-2cffdc3c0076")
	)
	(bus
		(pts
			(xy 166.37 142.24) (xy 166.37 139.7)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "848e827a-65dc-41b7-bffe-fe51f1778636")
	)
	(wire
		(pts
			(xy 115.57 222.25) (xy 121.92 222.25)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "84e0150b-1f8b-4373-92d5-1719a20ef56a")
	)
	(bus
		(pts
			(xy 97.79 111.76) (xy 97.79 114.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8527f22a-b412-4469-a970-e9b812042cd4")
	)
	(bus
		(pts
			(xy 113.03 144.78) (xy 113.03 147.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8791820a-989a-45d6-aa26-a7591a2c3ab6")
	)
	(wire
		(pts
			(xy 157.48 124.46) (xy 163.83 124.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "87ba19fc-ca0f-4c86-ac22-3d1fcdbbb403")
	)
	(bus
		(pts
			(xy 97.79 132.08) (xy 97.79 134.62)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "89276052-4f00-402e-a631-ea07e6151ac6")
	)
	(wire
		(pts
			(xy 49.53 129.54) (xy 55.88 129.54)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "89a0f505-6110-4167-9b93-a2a582d47088")
	)
	(wire
		(pts
			(xy 115.57 232.41) (xy 121.92 232.41)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8a94424a-c355-4ee4-9811-4f41140daa9f")
	)
	(bus
		(pts
			(xy 166.37 184.15) (xy 166.37 186.69)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8b09cc04-464b-4f63-a117-cc027187de82")
	)
	(wire
		(pts
			(xy 34.29 220.98) (xy 34.29 177.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8d4e804a-300d-4a6e-be72-dc73b9301b04")
	)
	(wire
		(pts
			(xy 160.02 154.94) (xy 177.8 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8df767cf-7867-445c-be6a-5942a67b2c7c")
	)
	(bus
		(pts
			(xy 97.79 134.62) (xy 97.79 137.16)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8e58b5af-ae8c-4c3c-be84-def913fa090c")
	)
	(wire
		(pts
			(xy 49.53 149.86) (xy 55.88 149.86)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "90c88e9c-cff5-4fee-9fa1-dd776196abe7")
	)
	(wire
		(pts
			(xy 160.02 232.41) (xy 177.8 232.41)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "91229eae-debc-45db-994f-b87a19127e14")
	)
	(wire
		(pts
			(xy 49.53 139.7) (xy 55.88 139.7)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "91e82f0f-88a7-495c-8220-5dc3ecd62cc6")
	)
	(wire
		(pts
			(xy 49.53 109.22) (xy 55.88 109.22)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "93d98202-f7f3-4eda-8952-0a7b7db490ad")
	)
	(wire
		(pts
			(xy 50.8 204.47) (xy 90.17 204.47)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "93f03bf3-2c2c-4189-9461-149490e5be58")
	)
	(wire
		(pts
			(xy 50.8 177.8) (xy 50.8 180.34)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "93fc4eb1-c470-45c6-b4de-168dbb73d30d")
	)
	(bus
		(pts
			(xy 166.37 114.3) (xy 166.37 116.84)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "94340a94-93ce-41d7-b578-0be8e914f0ad")
	)
	(bus
		(pts
			(xy 46.99 139.7) (xy 46.99 142.24)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "947e20fd-73b9-4a05-8e33-8ba06ab6a1d5")
	)
	(bus
		(pts
			(xy 113.03 137.16) (xy 113.03 139.7)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "97d1a411-5342-4c83-a198-61f7044d8eb7")
	)
	(wire
		(pts
			(xy 177.8 154.94) (xy 177.8 162.56)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "97e0ce9c-93d4-4de2-9049-c2958d5cf491")
	)
	(wire
		(pts
			(xy 115.57 114.3) (xy 121.92 114.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "981ea474-746d-4e29-9657-e11bfa71af8a")
	)
	(wire
		(pts
			(xy 39.37 232.41) (xy 43.18 232.41)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "98fd6742-413b-4454-8965-3dd8e67d1580")
	)
	(bus
		(pts
			(xy 46.99 124.46) (xy 46.99 127)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "99d91820-6d4c-4cfc-a163-462fcbd5aeb6")
	)
	(bus
		(pts
			(xy 113.03 177.8) (xy 113.03 181.61)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9a486625-a2c0-4a52-91bc-52b47e81115a")
	)
	(wire
		(pts
			(xy 115.57 227.33) (xy 121.92 227.33)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9c313100-d27c-42d6-b87e-055dace5c7cb")
	)
	(wire
		(pts
			(xy 34.29 255.27) (xy 50.8 255.27)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9ec01e79-67c5-46c3-ad63-47737c2e73b7")
	)
	(wire
		(pts
			(xy 157.48 199.39) (xy 163.83 199.39)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9ef0d03d-65a6-40d5-8f8c-3e9371cc1c71")
	)
	(wire
		(pts
			(xy 49.53 124.46) (xy 55.88 124.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9fa9c69e-ab18-424a-8266-34942b1eaded")
	)
	(wire
		(pts
			(xy 88.9 127) (xy 95.25 127)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a00bb1e2-030f-4285-b8c1-461431d3f4cf")
	)
	(wire
		(pts
			(xy 88.9 121.92) (xy 95.25 121.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a1f6ca68-b1d5-42ba-9328-d913f7ff87c4")
	)
	(wire
		(pts
			(xy 95.25 144.78) (xy 88.9 144.78)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a34b6fe3-9c39-425c-acdc-1e26d519dea6")
	)
	(wire
		(pts
			(xy 121.92 160.02) (xy 121.92 162.56)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a62ff0ff-eb44-4a9c-a831-bcd038e976fa")
	)
	(wire
		(pts
			(xy 49.53 147.32) (xy 55.88 147.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a6a6cc89-3d9e-47a7-9b7b-5696ec300f89")
	)
	(bus
		(pts
			(xy 113.03 181.61) (xy 113.03 184.15)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a93e4dda-6fef-4c75-a4b3-4573b6aaf94e")
	)
	(wire
		(pts
			(xy 157.48 116.84) (xy 163.83 116.84)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "aa3b08df-1d4f-4c3c-8f02-3675ca1007ac")
	)
	(wire
		(pts
			(xy 115.57 199.39) (xy 121.92 199.39)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "aa8cee48-8f6a-457a-9124-5cf1cd4fcf2a")
	)
	(wire
		(pts
			(xy 115.57 154.94) (xy 121.92 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ab546091-8704-4d6e-97ee-c4184d9a580d")
	)
	(bus
		(pts
			(xy 97.79 139.7) (xy 97.79 142.24)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "abec35b4-d5ca-472f-abb0-94f181d4c887")
	)
	(wire
		(pts
			(xy 115.57 217.17) (xy 121.92 217.17)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b02df893-db80-4f9b-8f45-a6247e9ac04f")
	)
	(wire
		(pts
			(xy 50.8 259.08) (xy 50.8 255.27)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b044a468-e852-4539-b1fb-d4ed36bbcd7e")
	)
	(wire
		(pts
			(xy 115.57 219.71) (xy 121.92 219.71)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b0e45305-6a7f-403f-aa91-1befee11b6aa")
	)
	(bus
		(pts
			(xy 46.99 116.84) (xy 46.99 119.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b1595e37-e843-40ef-ab64-980b6d9ca46f")
	)
	(bus
		(pts
			(xy 113.03 196.85) (xy 113.03 199.39)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b1ab6dfa-807e-4dbf-b67e-5344ed1d5bee")
	)
	(wire
		(pts
			(xy 34.29 255.27) (xy 34.29 240.03)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b2521753-c655-4803-b7e2-0bd55b7494e7")
	)
	(bus
		(pts
			(xy 113.03 147.32) (xy 113.03 149.86)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b60a1b04-2cdc-4706-9654-b5136d603467")
	)
	(bus
		(pts
			(xy 46.99 144.78) (xy 46.99 147.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b6409ca9-6f8b-4ee6-85c3-5f84ba739043")
	)
	(wire
		(pts
			(xy 49.53 142.24) (xy 55.88 142.24)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b67f8605-8298-4ad8-a142-bacb961afa4d")
	)
	(wire
		(pts
			(xy 115.57 134.62) (xy 121.92 134.62)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b7fb3c9d-b584-44ff-b578-7c26cf94c64c")
	)
	(wire
		(pts
			(xy 157.48 157.48) (xy 160.02 157.48)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b8d228e8-3f7a-4cb6-ab05-f69849cfa045")
	)
	(wire
		(pts
			(xy 88.9 106.68) (xy 95.25 106.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bb8fcadc-8007-47a2-86ab-1e1b03bfbd8e")
	)
	(wire
		(pts
			(xy 73.66 255.27) (xy 73.66 240.03)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bd7f4b93-99bd-41a8-8a7f-e5657904a775")
	)
	(bus
		(pts
			(xy 97.79 114.3) (xy 97.79 116.84)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bf0267fa-9a71-43ea-ab7d-a8b176a986db")
	)
	(bus
		(pts
			(xy 166.37 186.69) (xy 166.37 189.23)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bf1e6eae-4da4-48d0-9448-47c9c23d4871")
	)
	(bus
		(pts
			(xy 166.37 219.71) (xy 166.37 217.17)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bf904513-893f-4470-b91f-a6bb446e083a")
	)
	(bus
		(pts
			(xy 113.03 114.3) (xy 113.03 116.84)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c0081c57-d026-4ce5-af20-442a6336ee1f")
	)
	(bus
		(pts
			(xy 46.99 121.92) (xy 46.99 124.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c047f25e-be86-400a-9680-3204a8af48b3")
	)
	(wire
		(pts
			(xy 34.29 281.94) (xy 46.99 281.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c0c41bcf-7a01-4b03-acd0-e2cbcaf4e491")
	)
	(wire
		(pts
			(xy 88.9 134.62) (xy 95.25 134.62)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c10b6fb0-f4bd-478f-9fc7-47a91a3ec470")
	)
	(wire
		(pts
			(xy 31.75 240.03) (xy 31.75 246.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c1704c9a-2ef8-49a7-99b4-964355797006")
	)
	(wire
		(pts
			(xy 49.53 144.78) (xy 55.88 144.78)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c2a647ea-4711-4ee1-ba0b-cb62c86693b7")
	)
	(bus
		(pts
			(xy 113.03 224.79) (xy 113.03 227.33)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c2e9bd94-821d-4a9f-806b-a98ce3a5d70e")
	)
	(bus
		(pts
			(xy 113.03 104.14) (xy 113.03 106.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c317732e-88b8-41e5-9443-babc5d211aa7")
	)
	(bus
		(pts
			(xy 166.37 194.31) (xy 166.37 196.85)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c3255a98-40cc-466d-a791-bdccde763a92")
	)
	(wire
		(pts
			(xy 161.29 147.32) (xy 157.48 147.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c3453e9b-4e8b-4a4c-8254-d8e8ef638ee0")
	)
	(wire
		(pts
			(xy 50.8 177.8) (xy 55.88 177.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c34c97da-c5e2-49c4-8e99-c0eb4d0cb078")
	)
	(bus
		(pts
			(xy 97.79 124.46) (xy 97.79 127)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c34e4416-9809-42f8-8b26-7fd5d1a1e42f")
	)
	(wire
		(pts
			(xy 160.02 234.95) (xy 160.02 232.41)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c428498f-65f0-45b0-abe5-875a0d55a129")
	)
	(wire
		(pts
			(xy 55.88 106.68) (xy 49.53 106.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c61a6ce0-668c-4e74-bd9a-ecf358c58f32")
	)
	(bus
		(pts
			(xy 113.03 139.7) (xy 113.03 142.24)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c69c18b4-819c-4e4d-a5d5-c533cd0fc686")
	)
	(bus
		(pts
			(xy 166.37 189.23) (xy 166.37 191.77)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c7e88589-a4fa-4808-a159-360ca0ab1bf4")
	)
	(wire
		(pts
			(xy 97.79 154.94) (xy 97.79 201.93)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c80dc705-d1e5-45b4-8236-edda8335a497")
	)
	(wire
		(pts
			(xy 157.48 111.76) (xy 163.83 111.76)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c98ccbfc-0f5d-4542-bd0a-ada1d4295a3d")
	)
	(wire
		(pts
			(xy 157.48 184.15) (xy 163.83 184.15)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c9d8801d-492d-4f5b-aacc-b1460d5946c9")
	)
	(wire
		(pts
			(xy 88.9 129.54) (xy 95.25 129.54)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ca33b65f-8a90-44e1-9ca9-66dac448f7b0")
	)
	(bus
		(pts
			(xy 113.03 219.71) (xy 113.03 222.25)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ca791f62-1fcf-4ff3-9b8d-4b79b55a3a58")
	)
	(wire
		(pts
			(xy 88.9 109.22) (xy 95.25 109.22)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cb683be5-6985-4de8-936c-0c9f767714c4")
	)
	(bus
		(pts
			(xy 166.37 196.85) (xy 166.37 199.39)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cd2e2f0d-d2d5-47fd-938c-666790c305d6")
	)
	(wire
		(pts
			(xy 157.48 149.86) (xy 161.29 149.86)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cd499a0d-b9e0-43bc-8af5-6f0487e2b0ea")
	)
	(bus
		(pts
			(xy 97.79 121.92) (xy 97.79 124.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cde54a52-4758-4caf-8f81-a7b0d40151b4")
	)
	(wire
		(pts
			(xy 115.57 147.32) (xy 121.92 147.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cee117ca-fbc2-40c7-904f-4c8c9056a244")
	)
	(bus
		(pts
			(xy 46.99 152.4) (xy 46.99 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cf3cf338-25de-4152-b1e2-b34335b458b6")
	)
	(bus
		(pts
			(xy 46.99 132.08) (xy 46.99 134.62)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cfd08b26-1de3-4b24-b677-438e2f4ac526")
	)
	(bus
		(pts
			(xy 113.03 186.69) (xy 113.03 189.23)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d08c0d70-bf4b-4623-ba28-0d9ea67fee25")
	)
	(wire
		(pts
			(xy 157.48 234.95) (xy 160.02 234.95)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d22e2df3-f0d2-4a84-965a-755942e1e996")
	)
	(wire
		(pts
			(xy 49.53 116.84) (xy 55.88 116.84)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d2c5300e-b46e-49eb-a26e-76c4456b4fe0")
	)
	(wire
		(pts
			(xy 157.48 162.56) (xy 161.29 162.56)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d3e0c1dd-022b-4ae2-a7ca-13df98dd3118")
	)
	(wire
		(pts
			(xy 57.15 281.94) (xy 72.39 281.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d44d420d-8f84-4865-b21e-615adbdfc492")
	)
	(wire
		(pts
			(xy 50.8 212.09) (xy 50.8 255.27)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d7fa0024-0b45-4729-abda-2708dd339fb6")
	)
	(wire
		(pts
			(xy 55.88 187.96) (xy 50.8 187.96)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "da795a07-ee52-40e6-8b1c-928ceb1c12fc")
	)
	(wire
		(pts
			(xy 49.53 127) (xy 55.88 127)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "da8608bd-b094-47b4-866f-eace00d52a52")
	)
	(wire
		(pts
			(xy 157.48 194.31) (xy 163.83 194.31)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "db037a60-b3ad-454f-9090-6dcb0770c3b9")
	)
	(wire
		(pts
			(xy 49.53 134.62) (xy 55.88 134.62)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "db69476f-8233-47d8-955b-6db7823797b5")
	)
	(bus
		(pts
			(xy 97.79 116.84) (xy 97.79 119.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "dc43a8c0-7d93-4866-91f8-b7cfa6142bc9")
	)
	(bus
		(pts
			(xy 113.03 217.17) (xy 113.03 219.71)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "dcfe5a80-315e-4edc-805e-42898b588123")
	)
	(bus
		(pts
			(xy 113.03 111.76) (xy 113.03 114.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e0eb3e1a-1151-4b3e-8306-3194da666b08")
	)
	(wire
		(pts
			(xy 88.9 137.16) (xy 95.25 137.16)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e1051af1-5225-45a1-851b-e52aac27b4e9")
	)
	(wire
		(pts
			(xy 50.8 180.34) (xy 55.88 180.34)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e22b1ae3-f435-4ebb-a079-94d4e3053a64")
	)
	(wire
		(pts
			(xy 54.61 201.93) (xy 67.31 201.93)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e31a1d06-ceab-4634-921b-3268e118115b")
	)
	(wire
		(pts
			(xy 157.48 240.03) (xy 161.29 240.03)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e66c0898-04c6-4e51-9649-503a54692aa8")
	)
	(wire
		(pts
			(xy 157.48 109.22) (xy 163.83 109.22)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e81a9408-9ef8-491b-bc6d-6da158c0ed69")
	)
	(wire
		(pts
			(xy 115.57 207.01) (xy 121.92 207.01)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e93f8490-b983-40ae-9e35-1b80bf365ca6")
	)
	(wire
		(pts
			(xy 115.57 142.24) (xy 121.92 142.24)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "eb9a0104-c66c-4212-a44f-c4029a9c89c5")
	)
	(wire
		(pts
			(xy 121.92 240.03) (xy 107.95 240.03)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ebf8fedc-b96e-43d0-a21c-7c2432dcd685")
	)
	(bus
		(pts
			(xy 46.99 111.76) (xy 46.99 114.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ec8f09fd-32d5-4c18-a5be-35c4e7afd39c")
	)
	(bus
		(pts
			(xy 113.03 129.54) (xy 113.03 132.08)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ed952d09-843d-4ace-9e2e-6822696c1180")
	)
	(bus
		(pts
			(xy 113.03 212.09) (xy 113.03 214.63)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f181562a-e826-4916-96ec-b4bb920eec86")
	)
	(bus
		(pts
			(xy 113.03 127) (xy 113.03 129.54)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f1f8b04b-9412-48d5-8a0f-084ad51a043b")
	)
	(wire
		(pts
			(xy 115.57 124.46) (xy 121.92 124.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f30b2123-3143-4728-840d-1bec8b9c436e")
	)
	(wire
		(pts
			(xy 49.53 132.08) (xy 55.88 132.08)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f35959b9-c33a-494a-9d6e-b49eca3bb026")
	)
	(wire
		(pts
			(xy 115.57 129.54) (xy 121.92 129.54)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f45ba1e9-9ba5-4b72-aafa-75e145168dd3")
	)
	(bus
		(pts
			(xy 113.03 106.68) (xy 113.03 109.22)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f6c532fd-db1a-4afa-96bf-8b8221975c40")
	)
	(bus
		(pts
			(xy 46.99 127) (xy 46.99 129.54)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f6c6967b-aad0-4512-9f44-2f6168518142")
	)
	(wire
		(pts
			(xy 157.48 189.23) (xy 163.83 189.23)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f6c832c2-94a6-41a6-9efd-978509d2d844")
	)
	(bus
		(pts
			(xy 113.03 194.31) (xy 113.03 196.85)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f6e459ac-9cbd-4cb2-935a-a0abee333a15")
	)
	(bus
		(pts
			(xy 166.37 100.33) (xy 166.37 104.14)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f7027ecb-e37c-472e-9076-537e6c3fd978")
	)
	(wire
		(pts
			(xy 49.53 152.4) (xy 55.88 152.4)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "fa98fa7d-bb1b-4155-8fd3-24943195729f")
	)
	(bus
		(pts
			(xy 46.99 137.16) (xy 46.99 139.7)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "fc5ba464-8061-4c6c-86c5-35328e7cab71")
	)
	(wire
		(pts
			(xy 57.15 276.86) (xy 72.39 276.86)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "fc8f127d-397c-48f8-b193-23fef65a508e")
	)
	(wire
		(pts
			(xy 163.83 144.78) (xy 157.48 144.78)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "fe1ef64d-67f3-4d15-85f5-0a3e5fdcc167")
	)
	(wire
		(pts
			(xy 115.57 214.63) (xy 121.92 214.63)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ff61ee7e-addc-4db9-b025-1482e2dd39e9")
	)
	(label "A13"
		(at 50.8 139.7 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "027807b3-7dec-4250-847a-c8f92a313d6a")
	)
	(label "A9"
		(at 116.84 129.54 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "05f7f9e1-a171-4141-9240-14026f6e60e3")
	)
	(label "A0"
		(at 50.8 106.68 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "0acfa0d3-12ab-4f97-989e-42732d58a686")
	)
	(label "A2"
		(at 116.84 111.76 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "0d6c915e-ab11-4ff0-bd1c-96bf302391b3")
	)
	(label "A13"
		(at 116.84 139.7 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "0e36096a-8cf3-4a9f-83ca-3c9edfa75894")
	)
	(label "A15"
		(at 116.84 144.78 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "0fe65351-a394-4157-9d4a-eb4f968c45fc")
	)
	(label "A12"
		(at 116.84 137.16 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "167710be-40c5-4654-bc51-922236898d30")
	)
	(label "A1"
		(at 116.84 109.22 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "1743bb2b-39a0-4605-94cf-7ef70a17f222")
	)
	(label "D4"
		(at 90.17 116.84 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "178fc939-9cd4-4246-9ce9-eade8bc7dd6d")
	)
	(label "A3"
		(at 116.84 114.3 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "1b197beb-4930-427a-be8e-e0acab491364")
	)
	(label "D5"
		(at 158.75 196.85 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "1c388266-57c6-4548-9fcb-5c50948375ba")
	)
	(label "D15"
		(at 90.17 144.78 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "210937ae-d93e-4ee0-ac38-0d5d5924dfe4")
	)
	(label "A16"
		(at 50.8 147.32 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "21cf94de-8fdc-4075-adfc-c31f8befbfd2")
	)
	(label "D6"
		(at 90.17 121.92 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "2588a08a-f2a3-447b-a2e8-1403420a033f")
	)
	(label "A0"
		(at 116.84 106.68 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "282b4e7d-e7cb-430d-99cb-fe1c57808493")
	)
	(label "A10"
		(at 116.84 132.08 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "2bd7662e-3e62-4e1a-b145-e1e595feb8e3")
	)
	(label "A10"
		(at 50.8 132.08 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "2bfdd8dd-c4b8-4ba1-a027-0bb9976440c7")
	)
	(label "A12"
		(at 116.84 214.63 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "30ad891d-d5ff-483f-9233-6a0106cce409")
	)
	(label "A18"
		(at 116.84 229.87 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "30b856f5-a624-4992-aac8-b7aef9c9c762")
	)
	(label "A20"
		(at 158.75 222.25 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "3157febe-4cbf-48e8-997e-02395f27d182")
	)
	(label "D1"
		(at 90.17 109.22 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "3300c8a3-83c1-4764-8757-26f7a375bc2c")
	)
	(label "A19"
		(at 116.84 154.94 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "3683037a-ca67-4ef0-838d-90b285ed7a88")
	)
	(label "A6"
		(at 50.8 121.92 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "3797747a-cb4c-46e9-96b1-bc0456b96082")
	)
	(label "A8"
		(at 116.84 204.47 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "3bd85575-828e-4c55-b57a-ceac39541a1a")
	)
	(label "A13"
		(at 116.84 217.17 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "4392636f-f941-4faa-8bc9-ae00d3e0bc9d")
	)
	(label "D13"
		(at 158.75 119.38 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "47d5d97e-5749-498b-9677-72c417e95faf")
	)
	(label "D14"
		(at 158.75 121.92 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "483b6aee-ca8f-4cf3-bf62-c671333c78b8")
	)
	(label "D13"
		(at 90.17 139.7 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "497a3167-2861-489f-b2aa-a929245c5d10")
	)
	(label "D8"
		(at 90.17 127 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "498e4b88-6387-4997-9d55-30df5c1d5652")
	)
	(label "A15"
		(at 50.8 144.78 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "4dadd7b2-2c69-4016-b6ed-f8173487edf0")
	)
	(label "A3"
		(at 116.84 191.77 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "4f44e6e4-2776-4e2f-a5df-276ac1ffb7fb")
	)
	(label "A5"
		(at 116.84 119.38 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "508b9e0e-89e3-44c1-95b0-247bf82da24c")
	)
	(label "D1"
		(at 158.75 186.69 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "54f51f50-7e9f-467f-bb8f-029ec93cdcbc")
	)
	(label "A11"
		(at 50.8 134.62 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "5ca809b5-7ea6-4f48-a5f8-63cf36f6165e")
	)
	(label "A7"
		(at 50.8 124.46 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "5d0e1530-f44d-4039-980d-62741c0fee47")
	)
	(label "A18"
		(at 116.84 152.4 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "5ee36d7d-1b59-4773-836f-47bed88a38d3")
	)
	(label "A15"
		(at 116.84 222.25 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "62aac694-3a78-4aa5-be36-eddb1451c250")
	)
	(label "A2"
		(at 116.84 189.23 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "6c162362-3685-4c3a-bfde-9015879b3055")
	)
	(label "A12"
		(at 50.8 137.16 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "73f47571-7862-4226-997b-bf7cd4d76875")
	)
	(label "A4"
		(at 116.84 116.84 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "7b69733b-529d-435d-a742-361c08349393")
	)
	(label "D3"
		(at 158.75 191.77 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "7c0907c0-75dc-421b-a685-7c4c7951123d")
	)
	(label "A3"
		(at 50.8 114.3 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "7d5939e2-9ca5-4ba0-a7b3-3c0d5d1b3698")
	)
	(label "A16"
		(at 116.84 147.32 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "7db0f0ef-5426-4740-aca8-5c90ceebca9b")
	)
	(label "A5"
		(at 50.8 119.38 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "8393da7b-8d6f-4066-9e73-c68feddbd6ce")
	)
	(label "A6"
		(at 116.84 199.39 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "878cfc19-abb6-4275-87cb-01bd96de95c8")
	)
	(label "D8"
		(at 158.75 106.68 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "89754598-5b10-46bb-95cc-72420d824193")
	)
	(label "D9"
		(at 158.75 109.22 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "8b7817f5-6bbd-4dd0-9d47-f9de2b016ae4")
	)
	(label "D15"
		(at 158.75 124.46 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "902cd084-a153-4eed-a14d-7ea81146a78f")
	)
	(label "D0"
		(at 158.75 184.15 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "9717cf2c-dc98-4a76-a4cf-6bb163e73917")
	)
	(label "D9"
		(at 90.17 129.54 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "9a5c5cae-8035-4868-912c-b48d21ffecbc")
	)
	(label "A1"
		(at 50.8 109.22 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "9fd68cbf-f534-4e74-b12c-24e25759c91f")
	)
	(label "A19"
		(at 116.84 232.41 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "a214877d-cbdc-48ab-a204-81feef3d4951")
	)
	(label "A14"
		(at 116.84 219.71 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "a2956131-bad9-4741-ac60-3f25b82c4bd9")
	)
	(label "D6"
		(at 158.75 199.39 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "a650df3a-dc68-4271-8e52-6eba48b9dadf")
	)
	(label "A20"
		(at 158.75 144.78 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "a6959cf7-8a32-46b2-bd09-2b0df5bb6094")
	)
	(label "D10"
		(at 90.17 132.08 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "a755ec74-a06e-495b-a379-3b0691abc8f0")
	)
	(label "D7"
		(at 90.17 124.46 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "a809bc8c-185c-4f27-ba3b-11480a25479a")
	)
	(label "D11"
		(at 90.17 134.62 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "b2a23722-8dbf-40be-8c2d-bc480a1f0961")
	)
	(label "A8"
		(at 116.84 127 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "b5296be7-6112-4e72-82fd-effa455f7815")
	)
	(label "A0"
		(at 116.84 184.15 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "b8e8033e-f070-4aa2-a985-5d57ad5fd057")
	)
	(label "A7"
		(at 116.84 201.93 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "ba484c41-a164-45b8-a75d-4da1056a120a")
	)
	(label "A17"
		(at 50.8 149.86 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "c0778525-8082-40f2-8927-ad98946d888d")
	)
	(label "A17"
		(at 116.84 227.33 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "c449a9b3-ea05-4b6d-9d2b-bcfda2a65f4f")
	)
	(label "D0"
		(at 90.17 106.68 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "c66b5e35-2534-4076-ac1e-fa2b4aa438a4")
	)
	(label "D11"
		(at 158.75 114.3 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "c693b430-6328-41c0-89fd-8f9648e513cd")
	)
	(label "D4"
		(at 158.75 194.31 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "c851e152-5cb3-4c87-afdf-b5836901372d")
	)
	(label "D7"
		(at 158.75 201.93 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "c85ab0cc-32ea-48c4-b50c-5f25abff3e31")
	)
	(label "A1"
		(at 116.84 186.69 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "c96bb686-dc48-4897-8f3d-856ed57254dc")
	)
	(label "A11"
		(at 116.84 212.09 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "cd1c16b1-e168-47dd-a5bf-8a82054c1862")
	)
	(label "A19"
		(at 50.8 154.94 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "cd1eee14-4da8-4624-a173-8d70c9532cef")
	)
	(label "D12"
		(at 158.75 116.84 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "cfa6fd03-13db-4d8f-8e00-1664ad87151f")
	)
	(label "A18"
		(at 50.8 152.4 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "cfbe3c26-a2ce-4ef4-8f93-249cdba90332")
	)
	(label "A20"
		(at 50.8 157.48 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "d1a5c16d-886c-4038-a8a0-a8f1df692b05")
	)
	(label "A14"
		(at 116.84 142.24 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "d609f96d-38c8-494b-a5a4-a4c5d243188f")
	)
	(label "A2"
		(at 50.8 111.76 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "d6c71e3b-4613-43aa-b0f3-f1f1a5fca4fd")
	)
	(label "A8"
		(at 50.8 127 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "d73f3dde-13d4-42e0-aea4-f3b85ac6a382")
	)
	(label "D3"
		(at 90.17 114.3 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "d780989a-49bf-49aa-b698-bbcfbb0ed056")
	)
	(label "D12"
		(at 90.17 137.16 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "d9174e8f-3a53-44ec-b9c6-accdb76742ab")
	)
	(label "A7"
		(at 116.84 124.46 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "dcda21ed-357c-4211-b682-4d285bdec443")
	)
	(label "A11"
		(at 116.84 134.62 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "dd1d1716-909e-4a60-8072-0b21578e5dd7")
	)
	(label "A9"
		(at 50.8 129.54 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "df08de9f-bb3c-4fbf-91a4-e78846d70b34")
	)
	(label "A9"
		(at 116.84 207.01 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "dfa58fbf-9e3a-4e9d-8446-ce69de3b2adb")
	)
	(label "A4"
		(at 50.8 116.84 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "e04f765c-6fb0-42aa-ad40-235213d0cfbb")
	)
	(label "D10"
		(at 158.75 111.76 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "e75f882b-02df-4ad0-b2cb-aac0cffbc7ee")
	)
	(label "D5"
		(at 90.17 119.38 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "e87cce52-d671-47f2-8505-f1954e2aa7a1")
	)
	(label "A17"
		(at 116.84 149.86 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "ec32db30-a040-455a-93bf-f28872ca3abd")
	)
	(label "A10"
		(at 116.84 209.55 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "f0e883e4-51b8-4721-a2ac-10ead0a17dd2")
	)
	(label "A6"
		(at 116.84 121.92 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "f0f012cf-a1f5-474a-8101-eba3b1a34562")
	)
	(label "A16"
		(at 116.84 224.79 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "f0f301e2-dc9d-44ef-8d88-93c2cc538193")
	)
	(label "D2"
		(at 90.17 111.76 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "f4f055e7-b543-49b2-b84a-82ddc39e31a1")
	)
	(label "D14"
		(at 90.17 142.24 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "f6a3927e-ec18-4cdd-bab6-95ea5c89c21c")
	)
	(label "A5"
		(at 116.84 196.85 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "f6c89408-5405-4dc7-89b5-4e042793d17f")
	)
	(label "D2"
		(at 158.75 189.23 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "fa1d5674-d6e0-47af-9c13-bdc22d00b0dc")
	)
	(label "A14"
		(at 50.8 142.24 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "fa950fc1-7531-48f1-8b0e-b7a664f8c141")
	)
	(label "A4"
		(at 116.84 194.31 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "fcb35411-e14f-419e-8c56-2243a0ec5bdd")
	)
	(global_label "PWL"
		(shape input)
		(at 72.39 271.78 0)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify left)
		)
		(uuid "02c7fb72-700c-44bf-a273-c13fa1b978b7")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 72.39 271.78 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "~{LO_IN}"
		(shape output)
		(at 88.9 149.86 0)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify left)
		)
		(uuid "0a3479eb-9f07-4b67-ad35-5d5799ed8078")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 88.9 149.86 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "PWL"
		(shape input)
		(at 82.55 232.41 0)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify left)
		)
		(uuid "0c11e8b5-cc5d-4f2a-b400-6b19176c148d")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 82.55 232.41 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "PWH"
		(shape input)
		(at 34.29 271.78 180)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify right)
		)
		(uuid "0f6ff84f-c36b-49c1-9ca3-1d197fef3043")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 34.29 271.78 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
				(hide yes)
			)
		)
	)
	(global_label "ADDR"
		(shape input)
		(at 166.37 139.7 90)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left)
		)
		(uuid "13fc3bb2-8436-4324-9b32-361ae47cb426")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 166.37 139.7 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "PEH"
		(shape input)
		(at 161.29 162.56 0)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify left)
		)
		(uuid "1b0e5a2b-9c4c-43c3-b83d-3ee82fa54ea1")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 161.29 162.56 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "DATA"
		(shape bidirectional)
		(at 166.37 100.33 90)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left)
		)
		(uuid "2b4e9313-6ada-47ff-9651-36520ea4d0b5")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 166.37 100.33 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "PWH"
		(shape input)
		(at 105.41 157.48 180)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify right)
		)
		(uuid "2f772863-aa2c-4d3e-ba00-967b69cd726a")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 105.41 157.48 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "PEH"
		(shape input)
		(at 19.05 232.41 180)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify right)
		)
		(uuid "4d1425fe-8748-4033-8eea-aa63b252b948")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 19.05 232.41 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "~{LO_IN}"
		(shape input)
		(at 72.39 281.94 0)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify left)
		)
		(uuid "4e063150-c729-4962-8c41-c5ad6a139312")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 72.39 281.94 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "~{CE}"
		(shape output)
		(at 88.9 160.02 0)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify left)
		)
		(uuid "53f9cec5-89e3-4e46-b7cf-594f90a78051")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 88.9 160.02 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "~{CE}"
		(shape input)
		(at 161.29 147.32 0)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify left)
		)
		(uuid "61a71766-b5dc-4c17-bb8a-71edca663493")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 161.29 147.32 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "PWH"
		(shape input)
		(at 43.18 232.41 0)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify left)
		)
		(uuid "6e70e2be-1a5b-40c7-a778-41ca76fb0885")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 43.18 232.41 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "ADDR"
		(shape input)
		(at 113.03 177.8 90)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left)
		)
		(uuid "7f583845-1949-4486-ac68-e7ad262bd345")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 113.03 177.8 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "~{OE}"
		(shape input)
		(at 161.29 149.86 0)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify left)
		)
		(uuid "9f65cf7d-5b37-4313-b4f4-67dd9536cba4")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 161.29 149.86 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "~{OE}"
		(shape output)
		(at 88.9 157.48 0)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify left)
		)
		(uuid "a199ca51-4ca7-4d9b-b5b8-91462e4950a5")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 88.9 157.48 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "~{LO}"
		(shape input)
		(at 72.39 276.86 0)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify left)
		)
		(uuid "a25cb319-3888-403b-9253-7275c2de400c")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 72.39 276.86 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "~{OE}"
		(shape input)
		(at 161.29 227.33 0)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify left)
		)
		(uuid "a86c9219-39f3-433b-bab4-a4bd02795ddf")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 161.29 227.33 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "PEL"
		(shape input)
		(at 58.42 232.41 180)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify right)
		)
		(uuid "ad8ae7ee-1ac0-43fe-8314-716470212b9d")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 58.42 232.41 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "~{HI_IN}"
		(shape output)
		(at 88.9 152.4 0)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify left)
		)
		(uuid "b0556f6d-ccda-4001-8f86-3bf187ffd6d3")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 88.9 152.4 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "PEL"
		(shape input)
		(at 161.29 240.03 0)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify left)
		)
		(uuid "b1d93156-3721-420a-922e-067fb23c4658")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 161.29 240.03 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "~{HI_IN}"
		(shape input)
		(at 34.29 281.94 180)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify right)
		)
		(uuid "b384a024-f039-45c8-b75d-1b2b44af81a3")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 34.29 281.94 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
				(hide yes)
			)
		)
	)
	(global_label "~{LO}"
		(shape input)
		(at 161.29 229.87 0)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify left)
		)
		(uuid "b720c4d0-7ace-4fac-97e5-887b5cf8cb03")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 161.29 229.87 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "DATA"
		(shape bidirectional)
		(at 166.37 177.8 90)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left)
		)
		(uuid "bbc635b8-6595-451d-9671-0fb86ebc7624")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 166.37 177.8 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "~{HI}"
		(shape input)
		(at 34.29 276.86 180)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify right)
		)
		(uuid "bffe388c-3daa-4a6d-9e4d-24e56d519fb1")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 34.29 276.86 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
				(hide yes)
			)
		)
	)
	(global_label "~{HI}"
		(shape input)
		(at 161.29 152.4 0)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify left)
		)
		(uuid "c7a93340-a236-46f6-84df-dae0cbebb89f")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 161.29 152.4 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "ADDR"
		(shape output)
		(at 46.99 100.33 90)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left)
		)
		(uuid "cb741ba2-8a1b-418f-a7f0-05c903f5c688")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 46.99 100.33 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "ADDR"
		(shape input)
		(at 166.37 217.17 90)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left)
		)
		(uuid "d22fe6f1-e01a-453c-9d9e-f436af939412")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 166.37 217.17 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "DATA"
		(shape bidirectional)
		(at 97.79 100.33 90)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left)
		)
		(uuid "d2e5186f-0474-400a-b803-88ad42f7743e")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 97.79 100.33 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "~{CE}"
		(shape input)
		(at 161.29 224.79 0)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify left)
		)
		(uuid "d7f2b249-05f3-42a5-ac80-c6a9f0620429")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 161.29 224.79 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "PWL"
		(shape input)
		(at 105.41 234.95 180)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify right)
		)
		(uuid "e84d02a6-812b-45b4-acd7-8b3dc3984d78")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 105.41 234.95 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(global_label "ADDR"
		(shape input)
		(at 113.03 100.33 90)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left)
		)
		(uuid "fa65822f-6a0d-4e8f-9566-6ade65a41223")
		(property "Intersheetrefs" "${INTERSHEET_REFS}"
			(at 113.03 100.33 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
	)
	(symbol
		(lib_id "MegaDriveCart:smd_cart_connector_edge")
		(at 72.39 120.65 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005b96d488")
		(property "Reference" "CON1"
			(at 72.39 99.3902 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Value" "smd_cart_connector_edge"
			(at 72.39 102.0826 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Footprint" "MegaDriveCart:md_cart_edge_conn"
			(at 72.39 120.65 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 72.39 120.65 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 72.39 120.65 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "A17"
			(uuid "5a938494-8a0a-45c3-8a11-a0535fc40777")
		)
		(pin "A15"
			(uuid "806ad061-2ffb-4eb1-929a-578741d505e7")
		)
		(pin "A13"
			(uuid "3db1a484-5aab-41cd-afe9-240400968ce1")
		)
		(pin "A11"
			(uuid "256fd10e-fa18-428f-9f1f-cfc5a8ab07dc")
		)
		(pin "A09"
			(uuid "9babe423-4ac1-47b6-92c4-148682a13bb7")
		)
		(pin "A07"
			(uuid "f4184770-2a65-4ebd-b867-b80b4f5b934a")
		)
		(pin "A05"
			(uuid "ea88aeba-5ed9-4041-bd04-08bc685dca51")
		)
		(pin "A03"
			(uuid "dd556f8c-f7c0-43be-ac22-a8635d2cdeb8")
		)
		(pin "B04"
			(uuid "3aaa0852-eb6e-4b37-92c6-a76d507c441e")
		)
		(pin "B05"
			(uuid "abcb2f2b-0e12-4fb1-9ca9-0e30682dd48a")
		)
		(pin "A04"
			(uuid "73d8d6d5-22e9-4178-9cd9-a92097e66bc7")
		)
		(pin "A06"
			(uuid "a91e7b76-5052-461b-ac58-077a531af149")
		)
		(pin "A08"
			(uuid "87841738-2013-4dc4-8708-6b3439516f08")
		)
		(pin "A10"
			(uuid "0bdfcc59-09e7-48e8-8761-1b69b707313c")
		)
		(pin "A12"
			(uuid "89dc221c-8991-4456-8fd6-b5370627af6b")
		)
		(pin "A14"
			(uuid "f19e2ef8-4263-4050-9ace-813ca96d20fb")
		)
		(pin "A16"
			(uuid "3ccaff8f-c9f4-408a-8d22-d3d1dd853982")
		)
		(pin "B06"
			(uuid "3e3368ff-9ab0-4403-b882-bc396661a130")
		)
		(pin "B07"
			(uuid "29f47a53-9b8a-4dcc-a67a-3220a9ef5e1a")
		)
		(pin "B08"
			(uuid "f17de410-c89c-481c-990e-7cc808ccd270")
		)
		(pin "B09"
			(uuid "7e149ec6-9599-4089-bfdd-4a0ee6ef0891")
		)
		(pin "B10"
			(uuid "f6270a40-be71-4ce4-9543-9f0beeba2d8a")
		)
		(pin "B11"
			(uuid "652276c3-3b01-4ea4-a5e2-2258c0fa8de2")
		)
		(pin "B27"
			(uuid "11e38163-68e4-43e4-b4a0-6442790701e6")
		)
		(pin "B26"
			(uuid "5811e65b-7973-4b24-a628-4e499c61be9c")
		)
		(pin "B18"
			(uuid "a7c4abf8-7923-4b31-8171-b493282ad9df")
		)
		(pin "B19"
			(uuid "dea84bb1-4820-4aea-929f-630a0c2a8f7e")
		)
		(pin "A02"
			(uuid "15f6a725-8fec-4775-aa6c-4cc39710dc81")
		)
		(pin "A31"
			(uuid "cd6bd0b4-0777-42de-bd55-e01222be4a9e")
		)
		(pin "A01"
			(uuid "f50cc7ae-d84d-458f-a1ce-930d273f209a")
		)
		(pin "A18"
			(uuid "70ced193-d9e9-4a3a-93f9-0a8f088b0b8f")
		)
		(pin "A32"
			(uuid "c5db1e0d-6932-4fbc-bcc0-b6715550ad76")
		)
		(pin "A20"
			(uuid "6b8c7f94-a605-40ca-a835-b5fddfc50e66")
		)
		(pin "A23"
			(uuid "1eef41cc-3c49-47fd-8e77-1f9c8601f17d")
		)
		(pin "A26"
			(uuid "217e6fa4-1c73-4882-a189-ee749c206999")
		)
		(pin "A29"
			(uuid "1e7d15d4-c643-4288-b2ce-83fe97621688")
		)
		(pin "A28"
			(uuid "cef79e2b-987a-4ca6-8a23-9136becbf0a4")
		)
		(pin "A25"
			(uuid "746801e9-21be-4581-a11b-f346acc54280")
		)
		(pin "A22"
			(uuid "9d201d79-ddcc-466b-9983-a97d317e943e")
		)
		(pin "A19"
			(uuid "561d258a-dba8-4e51-a014-101db3a9b10a")
		)
		(pin "A21"
			(uuid "0e803d25-df6d-40f7-b458-3be19194a0fc")
		)
		(pin "A24"
			(uuid "e7164522-668f-4e68-942e-d5476fda1043")
		)
		(pin "A27"
			(uuid "de93e057-7f20-4ad5-901a-8cdaa19cc17e")
		)
		(pin "A30"
			(uuid "23200605-df95-4568-97bd-f719dbeb968a")
		)
		(pin "B25"
			(uuid "ed45201a-1d12-47d5-bad3-de60c03b92ee")
		)
		(pin "B24"
			(uuid "cfd8586e-4ba2-4528-b68b-2e2af591b62a")
		)
		(pin "B23"
			(uuid "45918028-1da2-436e-b0f3-6ef03a98363b")
		)
		(pin "B22"
			(uuid "00037a66-d107-4bb9-8580-af8a3c883f41")
		)
		(pin "B28"
			(uuid "5dd7c3b4-b4f9-457f-9934-69e72bccec3b")
		)
		(pin "B29"
			(uuid "2c598af2-351e-48a7-b8ae-bbe30e01b5f9")
		)
		(pin "B32"
			(uuid "f4a5921c-9fee-4de8-bb48-a43c9e353888")
		)
		(pin "B16"
			(uuid "a29a385d-b6dc-40c4-9048-06be22ff5185")
		)
		(pin "B17"
			(uuid "d3c404d6-497e-473a-89a8-1414d12464d8")
		)
		(pin "B20"
			(uuid "1296ec32-78c1-423b-8967-e206a6197ed5")
		)
		(pin "B30"
			(uuid "ecde6900-3726-4cfb-a4aa-b2bcd8e69bac")
		)
		(pin "B02"
			(uuid "91faafdb-8276-40ad-a1bb-76ff4923b95e")
		)
		(pin "B12"
			(uuid "025834d5-14a6-48a9-9e9b-ab53bc1ae1ab")
		)
		(pin "B13"
			(uuid "7e93f524-534f-4df0-b9cd-a95754d42487")
		)
		(pin "B14"
			(uuid "c9e694cc-0aae-4600-a907-a2b8d51e71da")
		)
		(pin "B15"
			(uuid "7f23c1da-6c76-458b-b5a4-b0bac90614cc")
		)
		(pin "B01"
			(uuid "8f62b40c-2c14-46d4-866f-de56d6481dde")
		)
		(pin "B03"
			(uuid "c43123ae-0c84-4687-a5ed-4771e73b9115")
		)
		(pin "B21"
			(uuid "3186cd45-a3a1-467f-992f-5c6ed170747c")
		)
		(pin "B31"
			(uuid "9321537e-949b-46b1-93d1-cab778e8e349")
		)
		(instances
			(project ""
				(path "/18b14b53-a9a3-4f8f-9d9c-81b8c20b5be1"
					(reference "CON1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:GND")
		(at 107.95 162.56 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005b986988")
		(property "Reference" "#PWR0102"
			(at 107.95 168.91 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 108.077 166.9542 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 107.95 162.56 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 107.95 162.56 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 107.95 162.56 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "cf4b2991-714a-495f-a9bf-6cf083d57a0e")
		)
		(instances
			(project ""
				(path "/18b14b53-a9a3-4f8f-9d9c-81b8c20b5be1"
					(reference "#PWR0102")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:+5V")
		(at 34.29 177.8 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005b9c93dd")
		(property "Reference" "#PWR0103"
			(at 34.29 181.61 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+5V"
			(at 34.671 173.4058 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 34.29 177.8 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 34.29 177.8 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 34.29 177.8 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "f27f699f-9823-44e2-af3c-324e1a356b8b")
		)
		(instances
			(project ""
				(path "/18b14b53-a9a3-4f8f-9d9c-81b8c20b5be1"
					(reference "#PWR0103")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:GND")
		(at 50.8 194.31 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005b9cf710")
		(property "Reference" "#PWR0104"
			(at 50.8 200.66 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 50.927 198.7042 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 50.8 194.31 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 50.8 194.31 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 50.8 194.31 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "1e680690-67b8-4aae-a592-b010d41968e5")
		)
		(instances
			(project ""
				(path "/18b14b53-a9a3-4f8f-9d9c-81b8c20b5be1"
					(reference "#PWR0104")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Device:C_Small")
		(at 107.95 160.02 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005ba2e721")
		(property "Reference" "C1"
			(at 109.22 158.75 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "104"
			(at 109.22 161.29 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "Capacitor_SMD:C_0805_2012Metric"
			(at 107.95 160.02 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Datasheet" "~"
			(at 107.95 160.02 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 107.95 160.02 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "ba91f296-2274-49db-948c-ed1f705f4aa0")
		)
		(pin "2"
			(uuid "8420064e-9d50-4b9a-9d6e-328a8f3d15b6")
		)
		(instances
			(project ""
				(path "/18b14b53-a9a3-4f8f-9d9c-81b8c20b5be1"
					(reference "C1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:GND")
		(at 177.8 162.56 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000061a870f5")
		(property "Reference" "#PWR0101"
			(at 177.8 168.91 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 177.927 166.9542 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 177.8 162.56 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 177.8 162.56 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 177.8 162.56 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "c7a0723a-e2a5-40d5-babd-1af1548e553d")
		)
		(instances
			(project ""
				(path "/18b14b53-a9a3-4f8f-9d9c-81b8c20b5be1"
					(reference "#PWR0101")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:GND")
		(at 50.8 259.08 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000061abfcba")
		(property "Reference" "#PWR0105"
			(at 50.8 265.43 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 50.927 263.4742 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 50.8 259.08 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 50.8 259.08 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 50.8 259.08 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "e5ff5e10-536f-4c00-8a9f-700d47455050")
		)
		(instances
			(project ""
				(path "/18b14b53-a9a3-4f8f-9d9c-81b8c20b5be1"
					(reference "#PWR0105")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "MegaDriveCart:cy62167e-TSOP48")
		(at 139.7 132.08 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000065992d57")
		(property "Reference" "U1"
			(at 139.7 99.949 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "cy62167e-TSOP48"
			(at 139.7 102.2604 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "MegaDriveCart:TSOP-I-48"
			(at 186.69 67.31 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 186.69 67.31 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 139.7 132.08 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "25"
			(uuid "e39d908e-a5e9-4ee6-abcb-4188fb8c67a4")
		)
		(pin "24"
			(uuid "2508517e-1295-4797-a629-28f9d5e4c669")
		)
		(pin "23"
			(uuid "c9cc6b2a-8d45-45dc-a86e-b3c8326af545")
		)
		(pin "22"
			(uuid "78b86cf4-e736-4609-b9b1-721c0a0469b3")
		)
		(pin "21"
			(uuid "ce88d48a-395e-409b-a5c1-8b86ff2812d1")
		)
		(pin "20"
			(uuid "c19389ba-c263-4280-be73-2516f48bd095")
		)
		(pin "19"
			(uuid "14b384ac-fb8e-42ef-8494-f5aea5bb8419")
		)
		(pin "18"
			(uuid "ae86f58c-34df-41dd-8319-2a4cc9f8ce88")
		)
		(pin "8"
			(uuid "833fd435-e672-4675-92bf-af081bfa6508")
		)
		(pin "7"
			(uuid "39e5afee-6403-4cda-afd5-243d8fe5e0f7")
		)
		(pin "6"
			(uuid "734e45d3-617f-43c3-892c-ab6aa28f17c6")
		)
		(pin "5"
			(uuid "8a0441c1-084e-4337-af31-afaafa622e7d")
		)
		(pin "4"
			(uuid "f3a18711-c396-43ef-829a-02d6eeae146e")
		)
		(pin "3"
			(uuid "840417ac-320f-433b-aa40-f2dca8fcead0")
		)
		(pin "2"
			(uuid "47f0e854-de97-4d27-a594-fbbb37cf096a")
		)
		(pin "1"
			(uuid "c11371c0-4ae3-4731-b487-179b71f98ad9")
		)
		(pin "48"
			(uuid "1c939a34-f5b6-4d6f-b3d3-69b8079b9c90")
		)
		(pin "17"
			(uuid "25341c03-681d-4789-ad53-2f2ec2fb5d4c")
		)
		(pin "16"
			(uuid "23dd7c42-266e-4b15-b470-7726e1fd84a7")
		)
		(pin "9"
			(uuid "ce4ccf95-e2aa-46bc-bf02-c5fd1052aef2")
		)
		(pin "37"
			(uuid "35314b21-0a79-4908-a8ce-3cf96259361b")
		)
		(pin "46"
			(uuid "a59e33b2-1743-4bc4-9edd-9dc796f49e86")
		)
		(pin "27"
			(uuid "477baa20-ff22-40ce-a28e-a0ba60a1b653")
		)
		(pin "10"
			(uuid "59cd908a-b266-440e-8ddb-df966e26fb09")
		)
		(pin "13"
			(uuid "14e6c5de-3e1c-4772-a5ea-81902a950a32")
		)
		(pin "29"
			(uuid "6b8a1929-848d-466f-8e82-3f4d0451fd1e")
		)
		(pin "31"
			(uuid "63057265-97c5-4ddf-a24c-90130548e327")
		)
		(pin "33"
			(uuid "018961aa-db00-4d2e-aa82-129023209a1c")
		)
		(pin "35"
			(uuid "39c81d97-b6ae-4e5f-bc6e-b8860d1eca3b")
		)
		(pin "38"
			(uuid "b8c01a9f-1507-4f2c-8bf6-22035101a237")
		)
		(pin "40"
			(uuid "59b25a17-3b6f-478d-a535-edd1769ec7a5")
		)
		(pin "42"
			(uuid "a658d1e1-ecd8-48fd-b37a-4e08b3d81e31")
		)
		(pin "44"
			(uuid "46dd040b-7a5a-497a-921c-3ad931082d81")
		)
		(pin "30"
			(uuid "e75506a6-4be4-4b94-a78e-394f5346db1c")
		)
		(pin "32"
			(uuid "d2e0acf2-ec66-4ee0-923c-157087904c53")
		)
		(pin "34"
			(uuid "40f9a2fd-ba5d-404d-b519-fbd07d6b142d")
		)
		(pin "36"
			(uuid "f6b9b8cb-b498-4cab-b4de-41cb49528274")
		)
		(pin "39"
			(uuid "37e47728-ce72-45e2-901b-b171b90db405")
		)
		(pin "41"
			(uuid "a24035c5-d561-466e-9c69-f704b9897197")
		)
		(pin "43"
			(uuid "32025400-fe5b-4aa2-acc0-7eaeef7a563f")
		)
		(pin "45"
			(uuid "93c2802d-9a69-4811-ab88-dbf444059e56")
		)
		(pin "26"
			(uuid "37947c87-d9bc-4fb6-b72f-25dbf91bbc7a")
		)
		(pin "28"
			(uuid "f63de004-b7ed-4075-b98f-95bee4855cdb")
		)
		(pin "11"
			(uuid "168b4e81-63ca-4814-b751-f5309abb76d4")
		)
		(pin "47"
			(uuid "f819833a-d8b1-43d1-a244-3c17f6975eb6")
		)
		(pin "14"
			(uuid "3eb292ce-e3d2-4241-ab4b-37c599674b89")
		)
		(pin "15"
			(uuid "e2266001-f7a9-469a-8e31-bc4f7e96ce3e")
		)
		(pin "12"
			(uuid "aa2f42c9-4956-4660-b34d-df63916f28fe")
		)
		(instances
			(project ""
				(path "/18b14b53-a9a3-4f8f-9d9c-81b8c20b5be1"
					(reference "U1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:+5V")
		(at 97.79 148.59 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000065a16315")
		(property "Reference" "#PWR01"
			(at 97.79 152.4 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+5V"
			(at 98.171 144.1958 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 97.79 148.59 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 97.79 148.59 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 97.79 148.59 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "837e8b07-1a1b-48e1-afff-677f0b6a43c9")
		)
		(instances
			(project ""
				(path "/18b14b53-a9a3-4f8f-9d9c-81b8c20b5be1"
					(reference "#PWR01")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:GND")
		(at 107.95 240.03 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000065ac719f")
		(property "Reference" "#PWR0109"
			(at 107.95 246.38 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 108.077 244.4242 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 107.95 240.03 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 107.95 240.03 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 107.95 240.03 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "0aaa577c-098d-48b0-9904-00b9126305c1")
		)
		(instances
			(project ""
				(path "/18b14b53-a9a3-4f8f-9d9c-81b8c20b5be1"
					(reference "#PWR0109")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "MegaDriveCart:cy62167e-TSOP48")
		(at 139.7 209.55 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000065ac71ab")
		(property "Reference" "U2"
			(at 139.7 177.419 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "cy62167e-TSOP48"
			(at 139.7 179.7304 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "MegaDriveCart:TSOP-I-48"
			(at 186.69 144.78 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 186.69 144.78 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 139.7 209.55 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "25"
			(uuid "06b3843e-7721-4bfe-a069-9a4e3e53a299")
		)
		(pin "24"
			(uuid "cd4e6646-5a20-496c-9908-e31e6888e037")
		)
		(pin "23"
			(uuid "9aead977-2508-4036-972a-c4d4840013ff")
		)
		(pin "22"
			(uuid "7f2ee775-f38f-41ac-a8ba-3b6baad90f10")
		)
		(pin "21"
			(uuid "e6660884-7ab9-4374-887c-692ead9133d7")
		)
		(pin "20"
			(uuid "4e8081bd-a448-4c7a-a7d0-aa0a989789c6")
		)
		(pin "19"
			(uuid "93c9fd6d-db1d-4200-9cc7-995054009521")
		)
		(pin "18"
			(uuid "136da4c9-32e6-45cf-a4a0-06dde1e83dd6")
		)
		(pin "8"
			(uuid "f28419c2-8165-4168-a4c1-cf53f2c77331")
		)
		(pin "7"
			(uuid "8fdce027-edc3-4152-b5a4-593273fead74")
		)
		(pin "6"
			(uuid "cd9457d1-0979-4b22-87fb-1ebf19eba99c")
		)
		(pin "5"
			(uuid "1c5c18e1-1bed-4208-9783-dbf997b0abbe")
		)
		(pin "4"
			(uuid "8c067f9e-23d0-4443-8669-aed34c25dd0f")
		)
		(pin "3"
			(uuid "c6ce9089-75c2-4915-b632-42e7b08ca2b1")
		)
		(pin "2"
			(uuid "74c41cf0-fbfd-4532-8075-63b3fa68e22a")
		)
		(pin "1"
			(uuid "88c72588-00b5-4993-b000-6b686d5399e5")
		)
		(pin "48"
			(uuid "5a2cfc97-a33d-413f-998e-dc63470c4901")
		)
		(pin "17"
			(uuid "78549acc-ffc8-4885-aa2b-30d1d6d45437")
		)
		(pin "16"
			(uuid "05b8779d-be1e-4159-af48-1ae457f50311")
		)
		(pin "9"
			(uuid "69072128-8f73-4c37-84f0-3190d0c4586b")
		)
		(pin "37"
			(uuid "e9f949fc-101b-4ec2-bba0-1446c231e343")
		)
		(pin "46"
			(uuid "5c081b6a-9a09-4c57-b9b5-edf15eb7ff0f")
		)
		(pin "27"
			(uuid "8eb2f84f-1c39-4b90-9bb6-27bd51c74dcc")
		)
		(pin "10"
			(uuid "be38f5e2-6ce1-481e-96ad-99d5570765ee")
		)
		(pin "13"
			(uuid "dcbd3da8-9d64-49cf-b16c-c70e8573fbf2")
		)
		(pin "29"
			(uuid "8ec70e6f-b68d-4124-a8d1-3cd196d30bf8")
		)
		(pin "31"
			(uuid "55b6b866-b250-42ae-81a4-3c5230d02d2a")
		)
		(pin "33"
			(uuid "69470cb3-e15d-4b44-b2a1-5181256f19b1")
		)
		(pin "35"
			(uuid "843a436d-92d1-4224-9d99-eead718e8ffd")
		)
		(pin "38"
			(uuid "a843609f-df9d-423c-bfbf-880e7074a2e7")
		)
		(pin "40"
			(uuid "e35e233c-7b8f-4bf8-a9a2-7cecc627e793")
		)
		(pin "42"
			(uuid "dd92a071-ff23-4579-acaa-e22475f168ba")
		)
		(pin "44"
			(uuid "95069b83-6e4a-4031-8b95-245c5fccffda")
		)
		(pin "30"
			(uuid "e2a6de04-20c8-4d12-898d-5b619c362d70")
		)
		(pin "32"
			(uuid "65652a05-bbef-45a2-8625-ff31e8e7b398")
		)
		(pin "34"
			(uuid "ad0b9f98-c3d4-43e0-a14d-9aeaf4b2334a")
		)
		(pin "36"
			(uuid "edc9d9fd-8d7c-4377-9f57-90b5b87a1104")
		)
		(pin "39"
			(uuid "9e1b78f7-fbf0-41b8-a380-8614cc9dad24")
		)
		(pin "41"
			(uuid "f5e355bd-80ac-43b8-b4bb-b362a6e752cd")
		)
		(pin "43"
			(uuid "e908c9ac-ef81-4167-8446-923845a71c2d")
		)
		(pin "45"
			(uuid "c0a1ba28-61ce-4b67-8ae8-326a96a9c54e")
		)
		(pin "26"
			(uuid "15cd7e18-05c3-4757-929f-d31c586e3dff")
		)
		(pin "28"
			(uuid "130324c8-484f-4589-8756-06ee5df32b6b")
		)
		(pin "11"
			(uuid "6f3cdf4e-b8be-4ab5-b5d3-e3d70dd56ea5")
		)
		(pin "47"
			(uuid "7a8c577d-85cd-43a6-acc6-a0e71bebf00e")
		)
		(pin "14"
			(uuid "74ee3a20-1512-484d-a5e4-72224340cf0a")
		)
		(pin "15"
			(uuid "d4d1d821-d3b7-4112-be9a-9a625a4f6631")
		)
		(pin "12"
			(uuid "6e0577c7-33ee-4eaa-ae62-a69ead8897c6")
		)
		(instances
			(project ""
				(path "/18b14b53-a9a3-4f8f-9d9c-81b8c20b5be1"
					(reference "U2")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "power:GND")
		(at 177.8 240.03 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000065ac71b5")
		(property "Reference" "#PWR0110"
			(at 177.8 246.38 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 177.927 244.4242 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 177.8 240.03 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 177.8 240.03 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 177.8 240.03 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "c939d0dc-470f-4bfa-b318-a8208a87f085")
		)
		(instances
			(project ""
				(path "/18b14b53-a9a3-4f8f-9d9c-81b8c20b5be1"
					(reference "#PWR0110")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Device:C_Small")
		(at 107.95 237.49 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000065ac71d6")
		(property "Reference" "C2"
			(at 109.22 236.22 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "104"
			(at 109.22 238.76 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "Capacitor_SMD:C_0805_2012Metric"
			(at 107.95 237.49 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Datasheet" "~"
			(at 107.95 237.49 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 107.95 237.49 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "21951925-6d47-447b-881c-63422e1d0554")
		)
		(pin "2"
			(uuid "929be05a-353b-41a4-92f7-dab020ac5504")
		)
		(instances
			(project ""
				(path "/18b14b53-a9a3-4f8f-9d9c-81b8c20b5be1"
					(reference "C2")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Device:Battery_Cell")
		(at 50.8 209.55 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000065b933bf")
		(property "Reference" "BT1"
			(at 53.7972 207.1116 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "Battery_Cell"
			(at 53.7972 209.423 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "Battery:BatteryHolder_Keystone_1058_1x2032"
			(at 50.8 208.026 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Datasheet" "~"
			(at 50.8 208.026 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 50.8 209.55 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "b06ebc07-cbc9-475d-a960-ca64db820932")
		)
		(pin "2"
			(uuid "9bceed6f-ae0d-49eb-a0f2-dbce7c4f1197")
		)
		(instances
			(project ""
				(path "/18b14b53-a9a3-4f8f-9d9c-81b8c20b5be1"
					(reference "BT1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Device:R_Small")
		(at 97.79 151.13 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000065c5c570")
		(property "Reference" "R1"
			(at 99.2886 149.9616 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "472"
			(at 99.2886 152.273 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "Resistor_SMD:R_0805_2012Metric"
			(at 97.79 151.13 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Datasheet" "~"
			(at 97.79 151.13 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 97.79 151.13 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "1"
			(uuid "b70cc2b2-d60c-430d-ab3a-df14bb323fd9")
		)
		(pin "2"
			(uuid "95a4ae62-41cb-4918-b1f5-02a0004e5261")
		)
		(instances
			(project ""
				(path "/18b14b53-a9a3-4f8f-9d9c-81b8c20b5be1"
					(reference "R1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "MegaDriveCart:BA6162")
		(at 34.29 232.41 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000065ca87cf")
		(property "Reference" "U3"
			(at 40.4876 231.2416 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "Value" "BA6162"
			(at 40.4876 233.553 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "Footprint" "Package_SO:SSOP-8_3.9x5.05mm_P1.27mm"
			(at 34.29 232.41 0)
			(effects
				(font
					(size 1.27 1.27)
					(italic yes)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 34.29 232.41 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 34.29 232.41 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "2"
			(uuid "21dc0e20-183c-4890-ad1a-bc9d2d0bf83c")
		)
		(pin "3"
			(uuid "eb469b65-30c9-4b4d-a816-2ca3559c0d52")
		)
		(pin "5"
			(uuid "66976c55-f82e-4f2e-b096-dae8253ada5f")
		)
		(pin "7"
			(uuid "e4513692-918b-4cbd-8ada-4371171fc9f5")
		)
		(pin "4"
			(uuid "12f3b199-f625-440e-b795-afa593de9bc5")
		)
		(pin "8"
			(uuid "460e6d72-3564-4907-9c90-108dd2b0ac2e")
		)
		(pin "1"
			(uuid "a409211c-9bd3-4534-b8b6-6245a7064481")
		)
		(pin "6"
			(uuid "7ba0806a-ffc6-434c-85ae-57ea8375666c")
		)
		(instances
			(project ""
				(path "/18b14b53-a9a3-4f8f-9d9c-81b8c20b5be1"
					(reference "U3")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "MegaDriveCart:BA6162")
		(at 73.66 232.41 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000065ca9ba2")
		(property "Reference" "U4"
			(at 79.8576 231.2416 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "Value" "BA6162"
			(at 79.8576 233.553 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "Footprint" "Package_SO:SSOP-8_3.9x5.05mm_P1.27mm"
			(at 73.66 232.41 0)
			(effects
				(font
					(size 1.27 1.27)
					(italic yes)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 73.66 232.41 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 73.66 232.41 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(pin "2"
			(uuid "0f21ae23-3f23-4ce4-93af-71fe07b40c28")
		)
		(pin "3"
			(uuid "44950b0a-87b7-42ee-85e6-cae2ea3c659a")
		)
		(pin "5"
			(uuid "ca605e99-e04c-4b29-88a1-906d964a61dc")
		)
		(pin "7"
			(uuid "4a04849a-eb86-4ec6-9234-5a784bc5326f")
		)
		(pin "4"
			(uuid "74491d4f-d1e2-48bc-aa4f-e7538c27fcff")
		)
		(pin "8"
			(uuid "33908e2d-744b-47e3-b144-a8b810710d9a")
		)
		(pin "1"
			(uuid "5a05f40a-3b07-428e-b621-710ecacd2654")
		)
		(pin "6"
			(uuid "ee7a4f22-90ce-4df1-97da-8300c55cfb59")
		)
		(instances
			(project ""
				(path "/18b14b53-a9a3-4f8f-9d9c-81b8c20b5be1"
					(reference "U4")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Switch:SW_Slide_DPDT")
		(at 52.07 276.86 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(fields_autoplaced yes)
		(uuid "522ae0a7-278f-4207-b5a7-77cb865005b6")
		(property "Reference" "SW1"
			(at 52.07 266.7 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "SW_Slide_DPDT"
			(at 52.07 269.24 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 66.04 271.78 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Datasheet" "~"
			(at 52.07 276.86 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Description" "Slide Switch, dual pole double throw"
			(at 52.07 276.86 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "2"
			(uuid "322d9ead-7249-47c3-9dc4-61338d7fb821")
		)
		(pin "3"
			(uuid "8d2e8c33-464f-41d1-8963-540d80946df7")
		)
		(pin "4"
			(uuid "f65d368e-02f8-4327-a677-b27441979c83")
		)
		(pin "1"
			(uuid "c547617a-d3ef-4761-8292-6edc09e112ea")
		)
		(pin "6"
			(uuid "6bec3abd-b35f-4a34-8a41-ea5750ef1725")
		)
		(pin "5"
			(uuid "808ebb12-409c-4d0a-b8c0-780484975820")
		)
		(instances
			(project ""
				(path "/18b14b53-a9a3-4f8f-9d9c-81b8c20b5be1"
					(reference "SW1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Device:R_US")
		(at 64.77 271.78 90)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(fields_autoplaced yes)
		(uuid "644c892b-6242-4cda-ab6d-8ac9e5ff45f9")
		(property "Reference" "R2"
			(at 64.77 265.43 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "10k"
			(at 64.77 267.97 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 65.024 270.764 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Datasheet" "~"
			(at 64.77 271.78 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Description" "Resistor, US symbol"
			(at 64.77 271.78 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "4672d231-cad7-4b69-8562-1eee0d87c3ca")
		)
		(pin "2"
			(uuid "671d0590-b044-419b-b9e8-f538fecaa18b")
		)
		(instances
			(project ""
				(path "/18b14b53-a9a3-4f8f-9d9c-81b8c20b5be1"
					(reference "R2")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Device:R_US")
		(at 40.64 271.78 90)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(fields_autoplaced yes)
		(uuid "d4439c20-4de2-4552-b251-a665bcf87810")
		(property "Reference" "R3"
			(at 40.64 265.43 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "10k"
			(at 40.64 267.97 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 40.894 270.764 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Datasheet" "~"
			(at 40.64 271.78 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Description" "Resistor, US symbol"
			(at 40.64 271.78 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "d724003a-9872-4492-8736-579376ccf3ad")
		)
		(pin "2"
			(uuid "1c8d5ddd-5d4b-4835-94a9-cfa42f46759d")
		)
		(instances
			(project "4m_cy62167e_x2"
				(path "/18b14b53-a9a3-4f8f-9d9c-81b8c20b5be1"
					(reference "R3")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "Switch:SW_SPST")
		(at 72.39 201.93 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(fields_autoplaced yes)
		(uuid "f70c14b1-0cce-4157-ad01-ac5858fcc630")
		(property "Reference" "SW2"
			(at 72.39 195.58 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "SW_SPST"
			(at 72.39 198.12 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 72.39 201.93 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Datasheet" "~"
			(at 72.39 201.93 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Description" "Single Pole Single Throw (SPST) switch"
			(at 72.39 201.93 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "74c6a3c8-79ab-48a5-ac95-679f46a76788")
		)
		(pin "2"
			(uuid "81f5113e-95d7-4de4-9bee-498da5363188")
		)
		(instances
			(project ""
				(path "/18b14b53-a9a3-4f8f-9d9c-81b8c20b5be1"
					(reference "SW2")
					(unit 1)
				)
			)
		)
	)
	(sheet_instances
		(path "/"
			(page "1")
		)
	)
	(embedded_fonts no)
)
